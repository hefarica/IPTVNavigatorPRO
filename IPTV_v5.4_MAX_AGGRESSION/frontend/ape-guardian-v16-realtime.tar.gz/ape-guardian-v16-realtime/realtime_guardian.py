"""
APE Guardian Engine v16 - Realtime Guardian
Módulo integrador principal que coordina todos los componentes de telemetría en tiempo real.
"""

import time
import asyncio
from typing import Dict, Optional
from collections import deque

from realtime.player_detector import PlayerDetector
from realtime.metrics_interceptor import MetricsInterceptor, StreamMetrics
from realtime.inference_engine import InferenceEngine, FreezePrediction
from realtime.jwt_dynamic_engine import JWTDynamicEngine
from realtime.error_recovery import ErrorRecoveryEngine


class RealtimeGuardian:
    """
    Coordinador principal del sistema de telemetría en tiempo real.
    
    Flujo de operación:
    1. Detecta el player y sus capacidades
    2. Intercepta métricas cada 50-100ms
    3. Predice freezes con el motor de inferencia
    4. Ajusta JWT dinámicamente si es necesario
    5. Gestiona errores HTTP con recuperación automática
    
    Objetivo: Latencia total <30ms desde detección hasta ajuste
    """
    
    def __init__(self, jwt_secret: str):
        self.player_detector = PlayerDetector()
        self.inference_engine = InferenceEngine()
        self.jwt_engine = JWTDynamicEngine(jwt_secret)
        self.error_recovery = ErrorRecoveryEngine()
        
        # Sesiones activas (por session_id)
        self.active_sessions = {}
        
    def start_session(self, 
                     session_id: str,
                     request_headers: Dict[str, str],
                     jwt_token: str) -> Dict[str, any]:
        """
        Inicia una nueva sesión de telemetría.
        
        Args:
            session_id: ID único de la sesión
            request_headers: Headers de la petición inicial
            jwt_token: JWT del usuario
            
        Returns:
            Información de la sesión iniciada
        """
        # Detectar player
        player_info = self.player_detector.detect(request_headers)
        
        # Crear interceptor de métricas
        telemetry_interval_ms = player_info['capabilities'].telemetry_interval_ms
        metrics_interceptor = MetricsInterceptor(session_id, telemetry_interval_ms)
        
        # Guardar sesión
        self.active_sessions[session_id] = {
            'session_id': session_id,
            'player_info': player_info,
            'metrics_interceptor': metrics_interceptor,
            'jwt_token': jwt_token,
            'start_time_ms': time.time() * 1000,
            'total_adjustments': 0,
            'total_errors': 0,
            'current_profile': 'P3'  # Default
        }
        
        return {
            'session_id': session_id,
            'player_type': player_info['player_type'],
            'player_version': player_info['player_version'],
            'capabilities': player_info['capabilities'].__dict__,
            'telemetry_interval_ms': telemetry_interval_ms,
            'status': 'active'
        }
    
    async def process_request(self,
                            session_id: str,
                            request_headers: Dict[str, str],
                            response_headers: Dict[str, str],
                            response_time_ms: float,
                            content_length: int) -> Dict[str, any]:
        """
        Procesa una petición y retorna ajustes si son necesarios.
        
        Este es el método principal que se llama en cada petición del player.
        
        Args:
            session_id: ID de la sesión
            request_headers: Headers de la petición
            response_headers: Headers de la respuesta
            response_time_ms: Tiempo de respuesta
            content_length: Tamaño del contenido
            
        Returns:
            {
                'needs_adjustment': bool,
                'new_jwt': str (opcional),
                'adjusted_headers': dict (opcional),
                'prediction': dict (opcional),
                'metrics': dict
            }
        """
        start_time_ms = time.time() * 1000
        
        # Verificar que la sesión existe
        if session_id not in self.active_sessions:
            return {'error': 'session_not_found'}
        
        session = self.active_sessions[session_id]
        metrics_interceptor = session['metrics_interceptor']
        player_info = session['player_info']
        
        # 1. Capturar métricas (objetivo: <10ms)
        metrics = metrics_interceptor.capture_metrics(
            request_headers,
            response_headers,
            response_time_ms,
            content_length
        )
        
        # 2. Verificar salud del stream
        is_healthy, warnings = metrics_interceptor.is_healthy()
        
        # 3. Predecir freezes (objetivo: <15ms)
        profile_target = self.jwt_engine.PROFILE_CONFIGS.get(
            session['current_profile'],
            self.jwt_engine.PROFILE_CONFIGS['P3']
        )
        
        prediction = self.inference_engine.predict_freeze(
            metrics_interceptor.metrics_buffer,
            profile_target,
            player_info['capabilities'].__dict__
        )
        
        # 4. Determinar si necesitamos ajustar
        needs_adjustment = prediction.will_freeze and prediction.confidence > 0.75
        
        result = {
            'needs_adjustment': needs_adjustment,
            'is_healthy': is_healthy,
            'warnings': warnings,
            'metrics': metrics.to_dict(),
            'prediction': {
                'will_freeze': prediction.will_freeze,
                'confidence': prediction.confidence,
                'cause': prediction.cause.value,
                'time_to_freeze_ms': prediction.time_to_freeze_ms,
                'severity': prediction.severity,
                'recommended_action': prediction.recommended_action.value
            } if needs_adjustment else None
        }
        
        # 5. Si necesitamos ajustar, generar nuevo JWT (objetivo: <20ms)
        if needs_adjustment:
            new_jwt, adjusted_headers = self.jwt_engine.adjust_jwt(
                session['jwt_token'],
                metrics,
                prediction,
                player_info['capabilities'].__dict__
            )
            
            # Actualizar sesión
            session['jwt_token'] = new_jwt
            session['total_adjustments'] += 1
            session['current_profile'] = adjusted_headers.get('profile', session['current_profile'])
            
            result['new_jwt'] = new_jwt
            result['adjusted_headers'] = adjusted_headers
        
        # Verificar tiempo total de procesamiento
        elapsed_ms = time.time() * 1000 - start_time_ms
        result['processing_time_ms'] = elapsed_ms
        
        if elapsed_ms > 30:
            print(f"WARNING: Request processing took {elapsed_ms:.1f}ms (target: <30ms)")
        
        return result
    
    async def handle_error(self,
                          session_id: str,
                          error_code: int,
                          context: Dict[str, any],
                          attempt_number: int = 1) -> Dict[str, any]:
        """
        Maneja un error HTTP con recuperación automática.
        
        Args:
            session_id: ID de la sesión
            error_code: Código de error HTTP
            context: Contexto del error
            attempt_number: Número de intento
            
        Returns:
            Resultado de la recuperación
        """
        if session_id in self.active_sessions:
            self.active_sessions[session_id]['total_errors'] += 1
        
        # Ejecutar estrategia de recuperación
        success, recovery_data = await self.error_recovery.recover(
            error_code,
            context,
            attempt_number
        )
        
        return {
            'error_code': error_code,
            'recovery_success': success,
            'recovery_data': recovery_data,
            'should_retry': success,
            'should_abort': self.error_recovery.should_abort(error_code)
        }
    
    def get_session_stats(self, session_id: str) -> Dict[str, any]:
        """
        Retorna estadísticas de una sesión.
        """
        if session_id not in self.active_sessions:
            return {'error': 'session_not_found'}
        
        session = self.active_sessions[session_id]
        metrics_interceptor = session['metrics_interceptor']
        
        uptime_s = (time.time() * 1000 - session['start_time_ms']) / 1000
        
        return {
            'session_id': session_id,
            'uptime_s': uptime_s,
            'player_type': session['player_info']['player_type'],
            'current_profile': session['current_profile'],
            'total_adjustments': session['total_adjustments'],
            'total_errors': session['total_errors'],
            'metrics_summary': metrics_interceptor.get_summary(),
            'jwt_adjustments': self.jwt_engine.get_adjustment_summary(),
            'error_statistics': self.error_recovery.get_error_statistics(),
            'inference_accuracy': self.inference_engine.get_accuracy_stats()
        }
    
    def end_session(self, session_id: str) -> Dict[str, any]:
        """
        Finaliza una sesión y retorna estadísticas finales.
        """
        if session_id not in self.active_sessions:
            return {'error': 'session_not_found'}
        
        stats = self.get_session_stats(session_id)
        del self.active_sessions[session_id]
        
        return {
            'status': 'ended',
            'final_stats': stats
        }
    
    def get_global_stats(self) -> Dict[str, any]:
        """
        Retorna estadísticas globales de todas las sesiones.
        """
        return {
            'active_sessions': len(self.active_sessions),
            'total_adjustments': sum(s['total_adjustments'] for s in self.active_sessions.values()),
            'total_errors': sum(s['total_errors'] for s in self.active_sessions.values()),
            'inference_accuracy': self.inference_engine.get_accuracy_stats(),
            'error_statistics': self.error_recovery.get_error_statistics()
        }


# Singleton global para usar en el Guardian Engine
_realtime_guardian = None

def get_realtime_guardian(jwt_secret: str = 'ape-guardian-secret-key-change-in-production') -> RealtimeGuardian:
    """
    Retorna la instancia singleton del Realtime Guardian.
    """
    global _realtime_guardian
    if _realtime_guardian is None:
        _realtime_guardian = RealtimeGuardian(jwt_secret)
    return _realtime_guardian
