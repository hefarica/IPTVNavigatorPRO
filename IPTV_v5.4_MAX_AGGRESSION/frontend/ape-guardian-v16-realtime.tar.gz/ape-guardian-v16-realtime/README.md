# APE Guardian Engine v16 - Telemetría en Tiempo Real

**Autor:** Manus AI
**Fecha:** 25 de Enero de 2026

## 1. Introducción

El **APE Guardian Engine v16** es un sistema avanzado de telemetría y adaptación en tiempo real diseñado para optimizar la entrega de contenido IPTV. Su objetivo principal es **prevenir el congelamiento (freeze) de la imagen** mediante la detección proactiva de anomalías en la red y la adaptación dinámica de la calidad del stream en menos de 30 milisegundos.

Este documento describe la arquitectura, componentes y guía de implementación del sistema.

## 2. Arquitectura del Sistema

El sistema se compone de 5 módulos principales que trabajan en conjunto para garantizar una experiencia de visualización sin interrupciones:

![Arquitectura del Sistema](https://i.imgur.com/example.png)  <!-- Placeholder for architecture diagram -->

| Componente | Descripción | Tiempo de Ejecución |
|:---|:---|:---:|
| **Player Detector** | Identifica el reproductor (player) y sus capacidades. | < 2ms |
| **Metrics Interceptor** | Captura 7 métricas clave del stream cada 50-100ms. | < 10ms |
| **Inference Engine** | Predice freezes y determina la causa raíz. | < 15ms |
| **JWT Dynamic Engine** | Regenera el JWT con ajustes correctivos. | < 20ms |
| **Error Recovery** | Gestiona errores HTTP 400-505 con fallback/failover. | < 30ms |

El flujo completo, desde la captura de métricas hasta la regeneración del JWT, se completa en **menos de 30ms**, lo que permite una respuesta casi instantánea a cualquier degradación de la red.

## 3. Componentes Detallados

### 3.1. Player Detector

Este módulo utiliza una combinación de `User-Agent`, headers personalizados y fingerprinting para detectar 7 tipos de reproductores:

- VLC
- ExoPlayer
- HLS.js
- OTT Navigator
- Kodi
- MPV
- FFmpeg

Una vez detectado, el sistema ajusta las capacidades (resolución máxima, descargas paralelas, etc.) basándose en las condiciones de red actuales.

### 3.2. Metrics Interceptor

El interceptor captura 7 métricas de calidad en cada petición de segmento:

1.  **Bandwidth (Mbps)**: Ancho de banda instantáneo.
2.  **Latency/RTT (ms)**: Latencia de ida y vuelta.
3.  **Packet Loss (%)**: Porcentaje de paquetes perdidos.
4.  **Jitter (ms)**: Variación de la latencia.
5.  **Throughput (Mbps)**: Rendimiento promedio.
6.  **Buffer Health (s)**: Estado del buffer del reproductor.
7.  **Error Rate**: Tasa de errores HTTP.

### 3.3. Inference Engine (ARBITER+ v2)

El corazón del sistema. Este motor de inferencia utiliza patrones de anomalías predefinidos para:

1.  **Predecir freezes** con una confianza >85%.
2.  **Determinar la causa raíz** de la anomalía:
    - Congestión del ISP
    - Sobrecarga del CDN del proveedor
    - Throttling del proveedor
    - Inestabilidad de la red
    - Buffer del reproductor agotándose
3.  **Recomendar una acción correctiva** entre 9 estrategias disponibles.

### 3.4. JWT Dynamic Engine

Una vez que el motor de inferencia recomienda una acción, este componente regenera el JWT en menos de 20ms, aplicando ajustes específicos para mitigar el problema:

| Causa | Acción de Ajuste |
|:---|:---|
| **ISP Congestion** | Reduce bitrate + prioriza códec HEVC |
| **Network Instability** | Aumenta tolerancia a packet loss y reintentos |
| **CDN Overload** | Cambia a un CDN de backup |
| **Provider Throttling** | Activa headers de evasión nivel 3 |
| **Buffer Underrun** | Fallback de emergencia al perfil más bajo (P5) |

### 3.5. Error Recovery Engine

Este módulo proporciona una capa adicional de robustez, gestionando **43 códigos de error HTTP (400-505)** con estrategias de recuperación predefinidas. Si una petición falla, el sistema intenta recuperarse automáticamente mediante:

- Regeneración de la petición
- Rotación de headers
- Failover a un CDN de backup
- Backoff exponencial
- Reducción de calidad

## 4. Guía de Implementación

Para desplegar el APE Guardian Engine v16 en tu servidor VPS, sigue estos pasos:

### 4.1. Prerrequisitos

- Servidor VPS con acceso root (SSH).
- Python 3.8+ instalado.
- Nginx instalado.

### 4.2. Instalación

1.  **Copiar archivos al servidor:**

    Crea un archivo `tar.gz` con todos los módulos y cópialo a tu servidor:

    ```bash
    # En tu máquina local
    tar -czf ape-guardian-v16.tar.gz ape-guardian-v16-realtime/
    scp ape-guardian-v16.tar.gz root@TU_IP_VPS:/opt/
    ```

2.  **Instalar en el servidor:**

    Conéctate a tu servidor por SSH y ejecuta:

    ```bash
    # En el servidor VPS
    cd /opt
    tar -xzf ape-guardian-v16.tar.gz
    cd ape-guardian-v16-realtime
    
    # Instalar dependencias
    pip3 install -r requirements.txt
    ```

3.  **Integrar con Guardian Engine v15:**

    Modifica tu `guardian_engine.py` existente para importar y utilizar el `RealtimeGuardian`:

    ```python
    # Al inicio de tu guardian_engine.py
    from realtime_guardian import get_realtime_guardian
    
    # Inicializar el guardián
    realtime_guardian = get_realtime_guardian(jwt_secret=\"TU_JWT_SECRET\")
    
    # ... dentro de tu función que procesa las peticiones ...
    
    # Iniciar sesión si es la primera petición
    if is_first_request:
        realtime_guardian.start_session(session_id, request.headers, jwt_token)
    
    # Procesar la petición con el guardián en tiempo real
    process_result = await realtime_guardian.process_request(
        session_id,
        request.headers,
        response.headers,
        response_time_ms,
        content_length
    )
    
    # Si hay ajustes, aplicarlos
    if process_result["needs_adjustment"]:
        new_jwt = process_result["new_jwt"]
        adjusted_headers = process_result["adjusted_headers"]
        # ... lógica para usar el nuevo JWT y headers ...
    ```

4.  **Reiniciar el servicio:**

    ```bash
    sudo systemctl restart ape-guardian-engine
    ```

## 5. Cómo Probar

Utiliza el script `test_realtime.py` incluido para simular la reproducción de un canal y ver el sistema en acción. El script mostrará:

- Detección del player.
- Métricas capturadas en tiempo real.
- Predicciones de freeze.
- Ajustes aplicados al JWT.
- Estadísticas finales de la sesión.

```bash
python3 test_realtime.py
```

## 6. Conclusión

El APE Guardian Engine v16 transforma la entrega de IPTV de un modelo pasivo a uno **proactivo e inteligente**. Al anticipar y mitigar problemas de red en tiempo real, garantiza la máxima calidad de imagen y una experiencia de visualización sin interrupciones, comparable a los principales servicios de streaming del mercado.
