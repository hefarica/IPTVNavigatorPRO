"""
Script de prueba del APE Guardian Engine v16 en tiempo real.
Simula reproducción de un canal y muestra cómo el sistema detecta y previene freezes.
"""

import sys
import time
import asyncio
import requests
import jwt as jwt_lib
from typing import Dict

sys.path.insert(0, '/home/ubuntu/ape-guardian-v16-realtime')

from realtime_guardian import get_realtime_guardian


def generate_jwt(profile_id='P2', user_id='test_user_123'):
    """Genera un JWT de prueba"""
    payload = {
        'user_id': user_id,
        'profile_id': profile_id,
        'abr_enabled': True,
        'screen_resolution': '1080p',
        'player_capability': 'high',
        'exp': int(time.time()) + 86400
    }
    return jwt_lib.encode(payload, 'ape-guardian-secret-key-change-in-production', algorithm='HS256')


def simulate_request(url: str, headers: Dict[str, str]) -> Dict[str, any]:
    """
    Simula una petición HTTP y captura métricas.
    """
    start_time = time.time()
    
    try:
        response = requests.head(url, headers=headers, timeout=10, allow_redirects=False)
        elapsed_ms = (time.time() - start_time) * 1000
        
        return {
            'success': True,
            'status_code': response.status_code,
            'response_headers': dict(response.headers),
            'response_time_ms': elapsed_ms,
            'content_length': int(response.headers.get('Content-Length', 0))
        }
    except Exception as e:
        elapsed_ms = (time.time() - start_time) * 1000
        return {
            'success': False,
            'error': str(e),
            'response_time_ms': elapsed_ms,
            'status_code': 0,
            'response_headers': {},
            'content_length': 0
        }


async def test_realtime_monitoring():
    """
    Prueba el sistema de telemetría en tiempo real.
    """
    print("=" * 80)
    print("APE GUARDIAN ENGINE V16 - PRUEBA EN TIEMPO REAL")
    print("=" * 80)
    print()
    
    # URL de la lista del usuario
    m3u8_url = "https://iptv-ape.duckdns.org/lists/APE_ULTIMATE_v9.0_20260125.m3u8"
    
    # Inicializar Guardian
    guardian = get_realtime_guardian()
    
    # Headers del player simulado
    request_headers = {
        'User-Agent': 'OTT-Navigator/1.6.9.5 (Android 11)',
        'Accept': 'application/vnd.apple.mpegurl',
        'X-Player-Type': 'ott_navigator',
        'X-Device-Type': 'android_tv',
        'X-Screen-Resolution': '1920x1080'
    }
    
    # Generar JWT
    jwt_token = generate_jwt('P2', 'test_user_realtime')
    
    print(f"📺 Player: OTT Navigator (Android TV)")
    print(f"🎯 URL: {m3u8_url}")
    print(f"🔑 JWT Profile: P2 (4K_EXTREME)")
    print()
    
    # Iniciar sesión
    session_id = f"test_session_{int(time.time())}"
    session_info = guardian.start_session(session_id, request_headers, jwt_token)
    
    print("✅ Sesión iniciada:")
    print(f"   - Session ID: {session_id}")
    print(f"   - Player detectado: {session_info['player_type']} v{session_info['player_version']}")
    print(f"   - Intervalo de telemetría: {session_info['telemetry_interval_ms']}ms")
    print(f"   - Parallel downloads: {session_info['capabilities']['max_parallel_downloads']}")
    print()
    
    # Simular múltiples peticiones (como si el player estuviera descargando segmentos)
    print("🔄 Simulando reproducción (10 segmentos)...")
    print()
    
    for i in range(10):
        # Simular petición
        result = simulate_request(m3u8_url, request_headers)
        
        if not result['success']:
            print(f"❌ Segmento {i+1}: Error - {result['error']}")
            continue
        
        # Procesar con el Guardian
        process_result = await guardian.process_request(
            session_id,
            request_headers,
            result['response_headers'],
            result['response_time_ms'],
            result['content_length']
        )
        
        # Mostrar resultados
        metrics = process_result['metrics']
        print(f"📊 Segmento {i+1}:")
        print(f"   - Bandwidth: {metrics['bandwidth_mbps']:.2f} Mbps")
        print(f"   - Latency: {metrics['rtt_ms']:.0f} ms")
        print(f"   - Packet Loss: {metrics['packet_loss_pct']:.1f}%")
        print(f"   - Buffer Health: {metrics['buffer_health_s']:.1f}s")
        print(f"   - Tiempo de procesamiento: {process_result['processing_time_ms']:.1f}ms")
        
        # Si hay predicción de freeze
        if process_result['needs_adjustment']:
            prediction = process_result['prediction']
            print(f"\n   ⚠️  FREEZE PREDICHO:")
            print(f"      - Causa: {prediction['cause']}")
            print(f"      - Confianza: {prediction['confidence']*100:.0f}%")
            print(f"      - Tiempo hasta freeze: {prediction['time_to_freeze_ms']}ms")
            print(f"      - Severidad: {prediction['severity']}")
            print(f"      - Acción recomendada: {prediction['recommended_action']}")
            
            if 'adjusted_headers' in process_result:
                adjusted = process_result['adjusted_headers']
                print(f"\n   🔧 AJUSTES APLICADOS:")
                for key, value in adjusted.items():
                    print(f"      - {key}: {value}")
                print(f"\n   ✅ JWT regenerado en {process_result['processing_time_ms']:.1f}ms")
        else:
            if process_result['is_healthy']:
                print(f"   ✅ Stream saludable")
            else:
                print(f"   ⚠️  Advertencias: {', '.join(process_result['warnings'])}")
        
        print()
        
        # Esperar un poco entre segmentos
        await asyncio.sleep(0.5)
    
    # Estadísticas finales
    print("=" * 80)
    print("ESTADÍSTICAS FINALES")
    print("=" * 80)
    
    stats = guardian.get_session_stats(session_id)
    
    print(f"\n📈 Sesión:")
    print(f"   - Duración: {stats['uptime_s']:.1f}s")
    print(f"   - Perfil actual: {stats['current_profile']}")
    print(f"   - Ajustes totales: {stats['total_adjustments']}")
    print(f"   - Errores totales: {stats['total_errors']}")
    
    if stats['jwt_adjustments']['total_adjustments'] > 0:
        print(f"\n🔧 Ajustes de JWT:")
        for cause, count in stats['jwt_adjustments']['by_cause'].items():
            print(f"   - {cause}: {count} veces")
    
    if stats['error_statistics']['total_errors'] > 0:
        print(f"\n❌ Errores:")
        print(f"   - Total: {stats['error_statistics']['total_errors']}")
        print(f"   - Recuperaciones exitosas: {stats['error_statistics']['successful_recoveries']}")
        print(f"   - Tasa de éxito: {stats['error_statistics']['success_rate']*100:.1f}%")
    
    print(f"\n🎯 Precisión del motor de inferencia:")
    print(f"   - Accuracy: {stats['inference_accuracy']['accuracy']*100:.1f}%")
    print(f"   - Predicciones totales: {stats['inference_accuracy']['total_predictions']}")
    
    # Finalizar sesión
    guardian.end_session(session_id)
    
    print("\n✅ Sesión finalizada")
    print("=" * 80)


if __name__ == '__main__':
    asyncio.run(test_realtime_monitoring())
