#!/bin/bash

# Script de instalación para APE Guardian Engine v16

# 1. Extraer archivos
cd /opt
tar -xzf ape-guardian-v16.tar.gz
cd ape-guardian-v16-realtime

# 2. Instalar dependencias
pip3 install -r requirements.txt

# 3. Integrar con Guardian Engine v15 (requiere modificación manual)
echo "-----------------------------------------------------"
echo "ACCIÓN REQUERIDA:"
echo "Modifica tu guardian_engine.py para integrar el RealtimeGuardian."
echo "Consulta la sección 4.3 de README.md para ver un ejemplo."
echo "-----------------------------------------------------"

# 4. Reiniciar servicio
sudo systemctl restart ape-guardian-engine

echo "✓ Instalación completada. El servicio se ha reiniciado."
