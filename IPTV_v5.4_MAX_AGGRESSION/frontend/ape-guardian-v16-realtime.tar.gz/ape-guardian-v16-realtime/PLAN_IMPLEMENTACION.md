# Plan de Implementación: APE Guardian Engine v16 - Telemetría en Tiempo Real

## Objetivo

Transformar el APE Guardian Engine v15 en un **sistema de telemetría y adaptación en tiempo real (v16)** que actúe como un "sniper" capaz de detectar, predecir y prevenir cortes de señal en menos de 30ms, ajustando dinámicamente el JWT y los headers HTTP sin que el usuario perciba ninguna interrupción.

## Arquitectura del Sistema

### Componentes Principales

```
┌─────────────────────────────────────────────────────────────┐
│                    APE GUARDIAN ENGINE v16                  │
│                   (Telemetría en Tiempo Real)               │
└─────────────────────────────────────────────────────────────┘
                              │
        ┌─────────────────────┼─────────────────────┐
        │                     │                     │
        ▼                     ▼                     ▼
┌──────────────┐    ┌──────────────────┐   ┌──────────────────┐
│   DETECTOR   │    │   INTERCEPTOR    │   │  MOTOR ARBITER+  │
│  DE PLAYERS  │    │  DE MÉTRICAS     │   │  (Inferencia)    │
│              │    │                  │   │                  │
│ • User-Agent │    │ • Bandwidth      │   │ • 7 Referentes   │
│ • Fingerprint│    │ • Latency (RTT)  │   │ • Predicción     │
│ • Capabilities│   │ • Packet Loss    │   │ • Causa (ISP/CDN)│
└──────────────┘    │ • Jitter         │   └──────────────────┘
                    │ • Throughput     │            │
                    │ • Buffer Health  │            │
                    │ • Error Codes    │            │
                    └──────────────────┘            │
                              │                     │
                              └──────────┬──────────┘
                                         ▼
                              ┌──────────────────────┐
                              │  JWT DYNAMIC ENGINE  │
                              │  (Ajuste en <30ms)   │
                              │                      │
                              │ • Regenera JWT       │
                              │ • Ajusta Headers     │
                              │ • Fallback/Failover  │
                              └──────────────────────┘
                                         │
                                         ▼
                              ┌──────────────────────┐
                              │   RESPONSE INJECTOR  │
                              │  (170+ Headers ABR)  │
                              └──────────────────────┘
```

## Fase 1: Detector de Players

### Objetivo
Identificar qué player está reproduciendo la lista para adaptar la estrategia de telemetría.

### Implementación

**Archivo**: `realtime/player_detector.py`

```python
class PlayerDetector:
    """
    Detecta el tipo de player basándose en User-Agent, headers y fingerprinting.
    """
    
    PLAYERS_DB = {
        'vlc': {
            'user_agent_patterns': ['VLC', 'libvlc'],
            'capabilities': {'hevc': True, 'hdr': False, 'parallel_dl': 2},
            'telemetry_interval_ms': 100
        },
        'exoplayer': {
            'user_agent_patterns': ['ExoPlayer', 'Android'],
            'capabilities': {'hevc': True, 'hdr': True, 'parallel_dl': 4},
            'telemetry_interval_ms': 50
        },
        'hls_js': {
            'user_agent_patterns': ['Mozilla', 'Chrome', 'Safari'],
            'capabilities': {'hevc': False, 'hdr': False, 'parallel_dl': 6},
            'telemetry_interval_ms': 100
        },
        'ott_navigator': {
            'user_agent_patterns': ['OTT-Navigator', 'IPTV'],
            'capabilities': {'hevc': True, 'hdr': True, 'parallel_dl': 4},
            'telemetry_interval_ms': 50
        }
    }
    
    def detect(self, user_agent: str, headers: dict) -> dict:
        """
        Detecta el player y retorna sus capacidades.
        """
        # Lógica de detección basada en patrones
        # Retorna: {'player': 'exoplayer', 'capabilities': {...}, 'telemetry_ms': 50}
```

## Fase 2: Interceptor de Métricas en Tiempo Real

### Objetivo
Capturar métricas del stream cada 50-100ms para detectar anomalías antes de que causen un freeze.

### Métricas Clave (7 Referentes de Calidad)

| Métrica | Umbral Normal | Umbral Crítico | Acción |
|:---|:---|:---|:---|
| **Bandwidth (Mbps)** | >5 Mbps | <2 Mbps | Downgrade perfil |
| **Latency/RTT (ms)** | <100ms | >300ms | Activar buffer agresivo |
| **Packet Loss (%)** | <1% | >5% | Cambiar CDN/ruta |
| **Jitter (ms)** | <20ms | >50ms | Aumentar buffer |
| **Throughput (Mbps)** | >bitrate_canal | <bitrate_canal*0.7 | Downgrade inmediato |
| **Buffer Health (s)** | >15s | <5s | Prefetch agresivo |
| **Error Rate (err/min)** | 0 | >3 | Failover a backup |

### Implementación

**Archivo**: `realtime/metrics_interceptor.py`

```python
class MetricsInterceptor:
    """
    Intercepta y analiza métricas del stream en tiempo real.
    Frecuencia: 50-100ms (configurable por player)
    """
    
    def __init__(self, session_id: str, telemetry_interval_ms: int = 100):
        self.session_id = session_id
        self.interval_ms = telemetry_interval_ms
        self.metrics_buffer = deque(maxlen=100)  # Últimos 10 segundos
        
    async def capture_metrics(self, request_headers: dict, response_headers: dict) -> dict:
        """
        Captura métricas de la petición/respuesta actual.
        """
        metrics = {
            'timestamp_ms': time.time() * 1000,
            'bandwidth_mbps': self._calculate_bandwidth(response_headers),
            'rtt_ms': self._extract_rtt(response_headers),
            'packet_loss_pct': self._estimate_packet_loss(),
            'jitter_ms': self._calculate_jitter(),
            'throughput_mbps': self._calculate_throughput(),
            'buffer_health_s': self._extract_buffer_health(request_headers),
            'error_code': response_headers.get('status_code', 200)
        }
        
        self.metrics_buffer.append(metrics)
        return metrics
    
    def get_trend(self, metric_name: str, window_ms: int = 1000) -> str:
        """
        Analiza la tendencia de una métrica (improving, stable, degrading).
        """
        # Análisis de tendencia en ventana de tiempo
```

## Fase 3: Motor de Inferencia (ARBITER+ v2)

### Objetivo
Predecir cortes de señal con 30ms de anticipación e inferir la causa (proveedor IPTV vs ISP).

### Algoritmo de Inferencia

**Archivo**: `realtime/inference_engine.py`

```python
class InferenceEngine:
    """
    Motor de inferencia que predice anomalías y determina la causa raíz.
    """
    
    ANOMALY_PATTERNS = {
        'isp_congestion': {
            'signature': {
                'bandwidth': 'degrading',
                'rtt': 'increasing',
                'packet_loss': 'increasing',
                'jitter': 'high'
            },
            'confidence_threshold': 0.85,
            'action': 'downgrade_profile_aggressive'
        },
        'cdn_overload': {
            'signature': {
                'throughput': 'degrading',
                'error_rate': 'increasing',
                'rtt': 'stable',
                'packet_loss': 'low'
            },
            'confidence_threshold': 0.80,
            'action': 'switch_cdn_or_failover'
        },
        'provider_throttling': {
            'signature': {
                'bandwidth': 'capped',
                'throughput': 'constant_low',
                'rtt': 'stable',
                'error_rate': 'low'
            },
            'confidence_threshold': 0.90,
            'action': 'inject_evasion_headers'
        }
    }
    
    def predict_freeze(self, metrics: list[dict], profile_target: dict) -> dict:
        """
        Predice si habrá un freeze en los próximos 30-100ms.
        
        Returns:
            {
                'will_freeze': bool,
                'confidence': float (0-1),
                'cause': str ('isp_congestion', 'cdn_overload', 'provider_throttling'),
                'time_to_freeze_ms': int,
                'recommended_action': str
            }
        """
        # Análisis de patrones
        # Machine learning simple (regresión lineal sobre tendencias)
        # Retorna predicción con confianza
```

## Fase 4: Sistema de Ajuste Dinámico de JWT

### Objetivo
Regenerar el JWT en <30ms con los headers ajustados para prevenir el freeze.

### Implementación

**Archivo**: `realtime/jwt_dynamic_engine.py`

```python
class JWTDynamicEngine:
    """
    Regenera JWT dinámicamente basándose en las métricas y predicciones.
    Tiempo de ejecución: <30ms
    """
    
    def __init__(self, secret_key: str):
        self.secret_key = secret_key
        self.adjustment_cache = {}  # Cache de ajustes recientes
        
    def adjust_jwt(self, 
                   current_jwt: str, 
                   metrics: dict, 
                   prediction: dict,
                   profile_target: dict) -> tuple[str, dict]:
        """
        Ajusta el JWT basándose en métricas y predicción.
        
        Returns:
            (new_jwt, adjusted_headers)
        """
        # Decodificar JWT actual
        payload = jwt.decode(current_jwt, self.secret_key, algorithms=['HS256'])
        
        # Aplicar ajustes basados en predicción
        if prediction['will_freeze']:
            if prediction['cause'] == 'isp_congestion':
                # Downgrade agresivo
                payload['profile_id'] = self._downgrade_profile(payload['profile_id'])
                payload['max_bitrate_mbps'] = metrics['bandwidth_mbps'] * 0.7
                payload['buffer_strategy'] = 'ultra_aggressive'
                payload['min_buffer_ms'] = 30000  # 30s
                
            elif prediction['cause'] == 'cdn_overload':
                # Cambiar CDN o failover
                payload['cdn_priority'] = 'backup'
                payload['edge_strategy'] = 'failover'
                payload['max_reconnect_attempts'] = 20
                
            elif prediction['cause'] == 'provider_throttling':
                # Inyectar headers de evasión
                payload['evasion_level'] = 3
                payload['header_rotation'] = True
        
        # Regenerar JWT
        new_jwt = jwt.encode(payload, self.secret_key, algorithm='HS256')
        
        # Generar headers ajustados
        adjusted_headers = self._generate_headers_from_payload(payload)
        
        return new_jwt, adjusted_headers
```

## Fase 5: Fallback/Failover Automático

### Objetivo
Implementar estrategias de recuperación automática ante errores HTTP 400-505.

### Estrategias por Código de Error

**Archivo**: `realtime/error_recovery.py`

```python
class ErrorRecoveryEngine:
    """
    Gestiona la recuperación automática ante errores HTTP.
    """
    
    ERROR_STRATEGIES = {
        # 4xx - Errores del cliente
        400: {'action': 'regenerate_request', 'retry': True, 'delay_ms': 0},
        401: {'action': 'refresh_jwt', 'retry': True, 'delay_ms': 0},
        403: {'action': 'rotate_headers', 'retry': True, 'delay_ms': 100},
        404: {'action': 'failover_to_backup', 'retry': False, 'delay_ms': 0},
        408: {'action': 'reduce_timeout', 'retry': True, 'delay_ms': 50},
        429: {'action': 'exponential_backoff', 'retry': True, 'delay_ms': 1000},
        
        # 5xx - Errores del servidor
        500: {'action': 'failover_immediate', 'retry': True, 'delay_ms': 0},
        502: {'action': 'switch_cdn', 'retry': True, 'delay_ms': 100},
        503: {'action': 'wait_and_retry', 'retry': True, 'delay_ms': 500},
        504: {'action': 'reduce_quality', 'retry': True, 'delay_ms': 0},
    }
    
    async def recover(self, error_code: int, context: dict) -> dict:
        """
        Ejecuta la estrategia de recuperación para el error dado.
        Tiempo máximo: 30ms
        """
```

## Fase 6: Integración Completa

### Flujo de Ejecución en Tiempo Real

```python
# guardian_engine_v16.py

class GuardianEngineV16:
    """
    APE Guardian Engine v16 - Telemetría en Tiempo Real
    """
    
    async def process_stream_request(self, session_id: str, m3u8_url: str):
        """
        Procesa una petición de stream con telemetría en tiempo real.
        """
        # 1. Detectar player (1-2ms)
        player_info = self.player_detector.detect(request.headers)
        
        # 2. Iniciar interceptor de métricas
        interceptor = MetricsInterceptor(
            session_id, 
            telemetry_interval_ms=player_info['telemetry_ms']
        )
        
        # 3. Loop de telemetría (cada 50-100ms)
        while stream_active:
            # Capturar métricas (5-10ms)
            metrics = await interceptor.capture_metrics(request, response)
            
            # Predecir freeze (10-15ms)
            prediction = self.inference_engine.predict_freeze(
                interceptor.metrics_buffer,
                current_profile
            )
            
            # Si se predice freeze, ajustar JWT (<30ms total)
            if prediction['will_freeze'] and prediction['confidence'] > 0.85:
                new_jwt, adjusted_headers = self.jwt_engine.adjust_jwt(
                    current_jwt,
                    metrics,
                    prediction,
                    current_profile
                )
                
                # Inyectar headers ajustados en la próxima respuesta
                self.inject_headers(adjusted_headers)
                
                # Log de acción preventiva
                logger.info(f"FREEZE PREVENTED: {prediction['cause']} "
                           f"detected with {prediction['confidence']*100}% confidence. "
                           f"Action: {prediction['recommended_action']}")
            
            await asyncio.sleep(player_info['telemetry_ms'] / 1000)
```

## Métricas de Rendimiento Esperadas

| Métrica | Objetivo | Medición |
|:---|:---|:---|
| **Latencia de detección** | <30ms | Desde anomalía hasta acción |
| **Tasa de predicción correcta** | >85% | Freezes predichos / Freezes reales |
| **Falsos positivos** | <10% | Acciones innecesarias |
| **Tiempo de ajuste JWT** | <20ms | Regeneración completa |
| **Overhead de CPU** | <5% | Uso adicional vs v15 |
| **Overhead de memoria** | <50MB | Por sesión activa |

## Próximos Pasos

1. Implementar los 5 módulos principales
2. Integrar con Guardian Engine v15 existente
3. Desplegar en VPS
4. Probar con lista real: `https://iptv-ape.duckdns.org/lists/APE_ULTIMATE_v9.0_20260125.m3u8`
5. Ajustar umbrales basándose en resultados reales
6. Documentar resultados y métricas
