"""
APE Guardian Engine v16 - JWT Dynamic Engine
Regenera JWT dinámicamente en <30ms con headers ajustados para prevenir freezes.
"""

import jwt
import time
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass

from .metrics_interceptor import StreamMetrics
from .inference_engine import FreezePrediction, AnomalyCause, RecommendedAction


@dataclass
class JWTAdjustment:
    """Registro de un ajuste realizado al JWT"""
    timestamp_ms: float
    original_profile: str
    new_profile: str
    cause: str
    action: str
    adjusted_fields: Dict[str, any]


class JWTDynamicEngine:
    """
    Regenera JWT dinámicamente basándose en métricas y predicciones.
    Tiempo de ejecución objetivo: <20ms
    """
    
    # Mapeo de perfiles (orden de calidad descendente)
    PROFILE_HIERARCHY = ['P0', 'P1', 'P2', 'P3', 'P4', 'P5']
    
    # Configuración de perfiles
    PROFILE_CONFIGS = {
        'P0': {'bitrate_mbps': 13.4, 'resolution': '3840x2160', 'buffer_ms': 8000},
        'P1': {'bitrate_mbps': 42.9, 'resolution': '7680x4320', 'buffer_ms': 5000},
        'P2': {'bitrate_mbps': 13.4, 'resolution': '3840x2160', 'buffer_ms': 3000},
        'P3': {'bitrate_mbps': 3.7, 'resolution': '1920x1080', 'buffer_ms': 2000},
        'P4': {'bitrate_mbps': 2.8, 'resolution': '1280x720', 'buffer_ms': 1500},
        'P5': {'bitrate_mbps': 1.5, 'resolution': '854x480', 'buffer_ms': 1000}
    }
    
    def __init__(self, secret_key: str):
        self.secret_key = secret_key
        self.adjustment_history = []
        self.adjustment_cache = {}  # Cache de ajustes recientes para evitar oscilaciones
        
    def adjust_jwt(self,
                   current_jwt: str,
                   metrics: StreamMetrics,
                   prediction: FreezePrediction,
                   player_capabilities: Dict[str, any]) -> Tuple[str, Dict[str, str]]:
        """
        Ajusta el JWT basándose en métricas y predicción de freeze.
        
        Args:
            current_jwt: JWT actual
            metrics: Métricas actuales del stream
            prediction: Predicción de freeze del motor de inferencia
            player_capabilities: Capacidades del player
            
        Returns:
            (new_jwt, adjusted_headers_dict)
        """
        start_time_ms = time.time() * 1000
        
        # Decodificar JWT actual
        try:
            payload = jwt.decode(current_jwt, self.secret_key, algorithms=['HS256'])
        except jwt.InvalidTokenError:
            # Si el JWT es inválido, retornar el original sin cambios
            return current_jwt, {}
        
        original_profile = payload.get('profile_id', 'P3')
        adjusted_fields = {}
        
        # Aplicar ajustes basados en la acción recomendada
        if prediction.recommended_action == RecommendedAction.DOWNGRADE_PROFILE_AGGRESSIVE:
            new_profile = self._downgrade_profile(original_profile, steps=2)
            payload['profile_id'] = new_profile
            payload['max_bitrate_mbps'] = metrics.bandwidth_mbps * 0.6
            payload['buffer_strategy'] = 'ultra_aggressive'
            payload['min_buffer_ms'] = 30000  # 30s
            payload['max_buffer_ms'] = 60000  # 60s
            adjusted_fields.update({
                'profile': new_profile,
                'bitrate': payload['max_bitrate_mbps'],
                'buffer_strategy': 'ultra_aggressive'
            })
        
        elif prediction.recommended_action == RecommendedAction.DOWNGRADE_PROFILE_MODERATE:
            new_profile = self._downgrade_profile(original_profile, steps=1)
            payload['profile_id'] = new_profile
            payload['max_bitrate_mbps'] = metrics.bandwidth_mbps * 0.75
            payload['buffer_strategy'] = 'aggressive'
            payload['min_buffer_ms'] = 20000  # 20s
            adjusted_fields.update({
                'profile': new_profile,
                'bitrate': payload['max_bitrate_mbps'],
                'buffer_strategy': 'aggressive'
            })
        
        elif prediction.recommended_action == RecommendedAction.INCREASE_BUFFER_AGGRESSIVE:
            payload['buffer_strategy'] = 'ultra_aggressive'
            payload['min_buffer_ms'] = 40000  # 40s
            payload['max_buffer_ms'] = 90000  # 90s
            payload['segment_preload'] = True
            payload['prefetch_segments'] = 5
            adjusted_fields.update({
                'buffer_strategy': 'ultra_aggressive',
                'min_buffer': '40s',
                'prefetch': 5
            })
        
        elif prediction.recommended_action == RecommendedAction.INCREASE_BUFFER_MODERATE:
            payload['buffer_strategy'] = 'aggressive'
            payload['min_buffer_ms'] = 25000  # 25s
            payload['max_buffer_ms'] = 60000  # 60s
            payload['prefetch_segments'] = 3
            adjusted_fields.update({
                'buffer_strategy': 'aggressive',
                'min_buffer': '25s',
                'prefetch': 3
            })
        
        elif prediction.recommended_action == RecommendedAction.SWITCH_CDN_OR_FAILOVER:
            payload['cdn_priority'] = 'backup'
            payload['edge_strategy'] = 'failover'
            payload['max_reconnect_attempts'] = 20
            payload['reconnect_delay_ms'] = 50
            payload['seamless_failover'] = True
            adjusted_fields.update({
                'cdn': 'backup',
                'failover': 'enabled',
                'reconnect_attempts': 20
            })
        
        elif prediction.recommended_action == RecommendedAction.INJECT_EVASION_HEADERS:
            payload['evasion_level'] = 3
            payload['header_rotation'] = True
            payload['user_agent_rotation'] = True
            payload['connection_pooling'] = False
            adjusted_fields.update({
                'evasion': 'level_3',
                'header_rotation': True
            })
        
        elif prediction.recommended_action == RecommendedAction.ENABLE_PARALLEL_DOWNLOADS:
            max_parallel = player_capabilities.get('max_parallel_downloads', 4)
            payload['parallel_segments'] = min(max_parallel, 6)
            payload['concurrent_downloads'] = min(max_parallel, 6)
            adjusted_fields.update({
                'parallel_downloads': payload['parallel_segments']
            })
        
        elif prediction.recommended_action == RecommendedAction.REDUCE_PARALLEL_DOWNLOADS:
            payload['parallel_segments'] = 1
            payload['concurrent_downloads'] = 1
            adjusted_fields.update({
                'parallel_downloads': 1
            })
        
        elif prediction.recommended_action == RecommendedAction.EMERGENCY_FALLBACK:
            # Downgrade al perfil más bajo y buffer máximo
            payload['profile_id'] = 'P5'
            payload['max_bitrate_mbps'] = 1.0
            payload['buffer_strategy'] = 'ultra_aggressive'
            payload['min_buffer_ms'] = 60000  # 60s
            payload['max_buffer_ms'] = 120000  # 120s
            payload['parallel_segments'] = 1
            payload['quality_preference'] = 'lowest'
            adjusted_fields.update({
                'profile': 'P5',
                'bitrate': 1.0,
                'buffer_strategy': 'emergency',
                'parallel_downloads': 1
            })
        
        # Ajustes adicionales basados en la causa
        if prediction.cause == AnomalyCause.ISP_CONGESTION:
            # Reducir demanda de ancho de banda
            payload['max_bitrate_mbps'] = min(
                payload.get('max_bitrate_mbps', 5.0),
                metrics.bandwidth_mbps * 0.7
            )
            payload['video_codecs_preference'] = ['hevc', 'h264']  # HEVC es más eficiente
            adjusted_fields['codec_preference'] = 'hevc'
        
        elif prediction.cause == AnomalyCause.NETWORK_INSTABILITY:
            # Aumentar tolerancia a jitter y packet loss
            payload['max_reconnect_attempts'] = 30
            payload['reconnect_delay_ms'] = 100
            payload['packet_loss_tolerance'] = 'high'
            adjusted_fields['reconnect_tolerance'] = 'high'
        
        # Actualizar timestamp
        payload['adjusted_at'] = int(time.time())
        payload['adjustment_reason'] = prediction.cause.value
        
        # Regenerar JWT
        new_jwt = jwt.encode(payload, self.secret_key, algorithm='HS256')
        
        # Generar headers ajustados
        adjusted_headers = self._generate_headers_from_payload(payload, player_capabilities)
        
        # Registrar ajuste
        adjustment = JWTAdjustment(
            timestamp_ms=time.time() * 1000,
            original_profile=original_profile,
            new_profile=payload.get('profile_id', original_profile),
            cause=prediction.cause.value,
            action=prediction.recommended_action.value,
            adjusted_fields=adjusted_fields
        )
        self.adjustment_history.append(adjustment)
        
        # Verificar tiempo de ejecución
        elapsed_ms = time.time() * 1000 - start_time_ms
        if elapsed_ms > 30:
            print(f"WARNING: JWT adjustment took {elapsed_ms:.1f}ms (target: <30ms)")
        
        return new_jwt, adjusted_headers
    
    def _downgrade_profile(self, current_profile: str, steps: int = 1) -> str:
        """
        Baja el perfil de calidad N pasos.
        """
        try:
            current_index = self.PROFILE_HIERARCHY.index(current_profile)
            new_index = min(current_index + steps, len(self.PROFILE_HIERARCHY) - 1)
            return self.PROFILE_HIERARCHY[new_index]
        except ValueError:
            return 'P3'  # Default a FHD si el perfil no se encuentra
    
    def _upgrade_profile(self, current_profile: str, steps: int = 1) -> str:
        """
        Sube el perfil de calidad N pasos.
        """
        try:
            current_index = self.PROFILE_HIERARCHY.index(current_profile)
            new_index = max(current_index - steps, 0)
            return self.PROFILE_HIERARCHY[new_index]
        except ValueError:
            return 'P3'
    
    def _generate_headers_from_payload(self,
                                      payload: Dict[str, any],
                                      player_capabilities: Dict[str, any]) -> Dict[str, str]:
        """
        Genera headers HTTP ajustados basándose en el payload del JWT.
        """
        headers = {}
        
        # Headers de video
        profile_id = payload.get('profile_id', 'P3')
        profile_config = self.PROFILE_CONFIGS.get(profile_id, self.PROFILE_CONFIGS['P3'])
        
        headers['X-Max-Bitrate'] = str(int(payload.get('max_bitrate_mbps', 5.0) * 1_000_000))
        headers['X-Max-Resolution'] = profile_config['resolution']
        headers['X-Target-Bitrate'] = str(int(profile_config['bitrate_mbps'] * 1_000_000))
        
        # Headers de códecs
        codec_pref = payload.get('video_codecs_preference', ['hevc', 'h264', 'vp9', 'av1'])
        headers['X-Video-Codecs'] = ','.join(codec_pref)
        
        # Headers de buffer
        buffer_strategy = payload.get('buffer_strategy', 'adaptive')
        headers['X-Buffer-Strategy'] = buffer_strategy
        headers['X-Min-Buffer-Ms'] = str(payload.get('min_buffer_ms', 15000))
        headers['X-Max-Buffer-Ms'] = str(payload.get('max_buffer_ms', 60000))
        
        # Headers de red
        headers['X-Parallel-Segments'] = str(payload.get('parallel_segments', 4))
        headers['X-Concurrent-Downloads'] = str(payload.get('concurrent_downloads', 4))
        headers['X-Prefetch-Segments'] = str(payload.get('prefetch_segments', 3))
        
        # Headers de reconexión
        headers['X-Max-Reconnect-Attempts'] = str(payload.get('max_reconnect_attempts', 10))
        headers['X-Reconnect-Delay-Ms'] = str(payload.get('reconnect_delay_ms', 100))
        
        # Headers de failover
        if payload.get('seamless_failover', False):
            headers['X-Seamless-Failover'] = 'true'
        
        if payload.get('cdn_priority') == 'backup':
            headers['X-CDN-Priority'] = 'backup'
            headers['X-Edge-Strategy'] = 'failover'
        
        # Headers de evasión (si están habilitados)
        if payload.get('evasion_level', 0) > 0:
            headers['X-Evasion-Level'] = str(payload['evasion_level'])
            if payload.get('header_rotation', False):
                headers['X-Header-Rotation'] = 'enabled'
        
        # Headers ABR personalizados (siempre incluidos)
        headers['X-Bandwidth-Preference'] = 'adaptive'  # Cambiar de unlimited a adaptive
        headers['X-BW-Estimation-Window'] = '10'
        headers['X-BW-Confidence-Threshold'] = '0.85'
        headers['X-BW-Smooth-Factor'] = '0.15'
        headers['X-Packet-Loss-Monitor'] = 'enabled'
        headers['X-RTT-Monitoring'] = 'enabled'
        headers['X-Congestion-Detect'] = 'enabled'
        
        # Headers de calidad
        quality_pref = payload.get('quality_preference', 'highest')
        headers['X-Quality-Preference'] = quality_pref
        
        return headers
    
    def can_upgrade(self, 
                   current_profile: str,
                   metrics: StreamMetrics,
                   min_stable_duration_s: int = 30) -> bool:
        """
        Determina si es seguro subir de perfil basándose en métricas estables.
        """
        # Verificar que las métricas sean saludables
        if metrics.bandwidth_mbps < 10:
            return False
        if metrics.rtt_ms > 100:
            return False
        if metrics.packet_loss_pct > 0.5:
            return False
        if metrics.buffer_health_s < 20:
            return False
        
        # Verificar que no haya habido ajustes recientes
        if self.adjustment_history:
            last_adjustment = self.adjustment_history[-1]
            time_since_last_ms = time.time() * 1000 - last_adjustment.timestamp_ms
            if time_since_last_ms < min_stable_duration_s * 1000:
                return False
        
        # Verificar que no estemos en el perfil máximo
        if current_profile == self.PROFILE_HIERARCHY[0]:
            return False
        
        return True
    
    def get_adjustment_summary(self) -> Dict[str, any]:
        """
        Retorna un resumen de los ajustes realizados.
        """
        if not self.adjustment_history:
            return {'total_adjustments': 0}
        
        total = len(self.adjustment_history)
        by_cause = {}
        by_action = {}
        
        for adj in self.adjustment_history:
            by_cause[adj.cause] = by_cause.get(adj.cause, 0) + 1
            by_action[adj.action] = by_action.get(adj.action, 0) + 1
        
        return {
            'total_adjustments': total,
            'by_cause': by_cause,
            'by_action': by_action,
            'last_adjustment': {
                'timestamp': self.adjustment_history[-1].timestamp_ms,
                'profile_change': f"{self.adjustment_history[-1].original_profile} -> {self.adjustment_history[-1].new_profile}",
                'cause': self.adjustment_history[-1].cause,
                'action': self.adjustment_history[-1].action
            }
        }
