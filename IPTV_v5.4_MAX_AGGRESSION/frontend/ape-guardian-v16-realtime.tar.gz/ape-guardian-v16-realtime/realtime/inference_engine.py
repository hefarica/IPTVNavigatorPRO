"""
APE Guardian Engine v16 - Inference Engine (ARBITER+ v2)
Motor de inferencia que predice freezes con 30ms de anticipación e infiere la causa raíz.
"""

import time
import statistics
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from enum import Enum
from collections import deque

from .metrics_interceptor import StreamMetrics, TrendDirection


class AnomalyCause(Enum):
    """Causa raíz de la anomalía detectada"""
    ISP_CONGESTION = "isp_congestion"  # Congestión del ISP del usuario
    CDN_OVERLOAD = "cdn_overload"  # Sobrecarga del CDN del proveedor
    PROVIDER_THROTTLING = "provider_throttling"  # Throttling del proveedor IPTV
    NETWORK_INSTABILITY = "network_instability"  # Inestabilidad general de red
    BUFFER_UNDERRUN = "buffer_underrun"  # Buffer del player agotándose
    UNKNOWN = "unknown"


class RecommendedAction(Enum):
    """Acción recomendada para prevenir el freeze"""
    DOWNGRADE_PROFILE_AGGRESSIVE = "downgrade_profile_aggressive"
    DOWNGRADE_PROFILE_MODERATE = "downgrade_profile_moderate"
    INCREASE_BUFFER_AGGRESSIVE = "increase_buffer_aggressive"
    INCREASE_BUFFER_MODERATE = "increase_buffer_moderate"
    SWITCH_CDN_OR_FAILOVER = "switch_cdn_or_failover"
    INJECT_EVASION_HEADERS = "inject_evasion_headers"
    ENABLE_PARALLEL_DOWNLOADS = "enable_parallel_downloads"
    REDUCE_PARALLEL_DOWNLOADS = "reduce_parallel_downloads"
    EMERGENCY_FALLBACK = "emergency_fallback"
    NO_ACTION = "no_action"


@dataclass
class FreezePrediction:
    """Predicción de freeze"""
    will_freeze: bool
    confidence: float  # 0-1
    cause: AnomalyCause
    time_to_freeze_ms: int
    recommended_action: RecommendedAction
    severity: str  # 'low', 'medium', 'high', 'critical'
    details: Dict[str, any]


class InferenceEngine:
    """
    Motor de inferencia ARBITER+ v2 que predice freezes y determina la causa raíz.
    Tiempo de ejecución: <15ms por predicción
    """
    
    # Patrones de anomalías conocidos
    ANOMALY_PATTERNS = {
        AnomalyCause.ISP_CONGESTION: {
            'signature': {
                'bandwidth_trend': [TrendDirection.DEGRADING, TrendDirection.CRITICAL],
                'rtt_trend': [TrendDirection.DEGRADING, TrendDirection.CRITICAL],
                'packet_loss_trend': [TrendDirection.DEGRADING, TrendDirection.CRITICAL],
                'jitter_high': True
            },
            'confidence_threshold': 0.85,
            'action': RecommendedAction.DOWNGRADE_PROFILE_AGGRESSIVE
        },
        AnomalyCause.CDN_OVERLOAD: {
            'signature': {
                'throughput_trend': [TrendDirection.DEGRADING, TrendDirection.CRITICAL],
                'error_rate_high': True,
                'rtt_trend': [TrendDirection.STABLE],
                'packet_loss_low': True
            },
            'confidence_threshold': 0.80,
            'action': RecommendedAction.SWITCH_CDN_OR_FAILOVER
        },
        AnomalyCause.PROVIDER_THROTTLING: {
            'signature': {
                'bandwidth_capped': True,
                'throughput_constant_low': True,
                'rtt_trend': [TrendDirection.STABLE],
                'error_rate_low': True
            },
            'confidence_threshold': 0.90,
            'action': RecommendedAction.INJECT_EVASION_HEADERS
        },
        AnomalyCause.NETWORK_INSTABILITY: {
            'signature': {
                'jitter_high': True,
                'packet_loss_trend': [TrendDirection.DEGRADING],
                'rtt_unstable': True
            },
            'confidence_threshold': 0.75,
            'action': RecommendedAction.INCREASE_BUFFER_AGGRESSIVE
        },
        AnomalyCause.BUFFER_UNDERRUN: {
            'signature': {
                'buffer_health_critical': True,
                'throughput_below_bitrate': True
            },
            'confidence_threshold': 0.95,
            'action': RecommendedAction.EMERGENCY_FALLBACK
        }
    }
    
    def __init__(self):
        self.prediction_history = deque(maxlen=100)
        self.false_positives = 0
        self.true_positives = 0
        
    def predict_freeze(self, 
                      metrics_buffer: deque,
                      profile_target: Dict[str, any],
                      player_capabilities: Dict[str, any]) -> FreezePrediction:
        """
        Predice si habrá un freeze en los próximos 30-100ms.
        
        Args:
            metrics_buffer: Buffer de métricas recientes (últimos 10s)
            profile_target: Perfil objetivo del canal
            player_capabilities: Capacidades del player detectado
            
        Returns:
            FreezePrediction con la predicción y acción recomendada
        """
        if len(metrics_buffer) < 5:
            return FreezePrediction(
                will_freeze=False,
                confidence=0.0,
                cause=AnomalyCause.UNKNOWN,
                time_to_freeze_ms=0,
                recommended_action=RecommendedAction.NO_ACTION,
                severity='low',
                details={}
            )
        
        # Convertir deque a lista para análisis
        metrics_list = list(metrics_buffer)
        latest_metrics = metrics_list[-1]
        
        # Analizar tendencias
        trends = self._analyze_trends(metrics_list)
        
        # Detectar patrones de anomalías
        anomaly_scores = {}
        for cause, pattern in self.ANOMALY_PATTERNS.items():
            score = self._match_pattern(latest_metrics, trends, pattern['signature'])
            if score >= pattern['confidence_threshold']:
                anomaly_scores[cause] = score
        
        # Si no hay anomalías detectadas
        if not anomaly_scores:
            return FreezePrediction(
                will_freeze=False,
                confidence=0.0,
                cause=AnomalyCause.UNKNOWN,
                time_to_freeze_ms=0,
                recommended_action=RecommendedAction.NO_ACTION,
                severity='low',
                details={'trends': trends}
            )
        
        # Seleccionar la anomalía con mayor confianza
        primary_cause = max(anomaly_scores, key=anomaly_scores.get)
        confidence = anomaly_scores[primary_cause]
        
        # Estimar tiempo hasta el freeze
        time_to_freeze_ms = self._estimate_time_to_freeze(
            latest_metrics,
            trends,
            profile_target
        )
        
        # Determinar severidad
        severity = self._calculate_severity(confidence, time_to_freeze_ms)
        
        # Obtener acción recomendada
        recommended_action = self.ANOMALY_PATTERNS[primary_cause]['action']
        
        # Ajustar acción basándose en severidad y capacidades del player
        recommended_action = self._adjust_action(
            recommended_action,
            severity,
            player_capabilities,
            latest_metrics
        )
        
        prediction = FreezePrediction(
            will_freeze=True,
            confidence=confidence,
            cause=primary_cause,
            time_to_freeze_ms=time_to_freeze_ms,
            recommended_action=recommended_action,
            severity=severity,
            details={
                'trends': trends,
                'anomaly_scores': {k.value: v for k, v in anomaly_scores.items()},
                'current_metrics': latest_metrics.to_dict()
            }
        )
        
        self.prediction_history.append(prediction)
        return prediction
    
    def _analyze_trends(self, metrics_list: List[StreamMetrics]) -> Dict[str, str]:
        """Analiza las tendencias de todas las métricas"""
        if len(metrics_list) < 3:
            return {}
        
        trends = {}
        
        # Analizar cada métrica
        for metric_name in ['bandwidth_mbps', 'rtt_ms', 'packet_loss_pct', 
                           'jitter_ms', 'throughput_mbps', 'buffer_health_s']:
            values = [getattr(m, metric_name) for m in metrics_list]
            trend = self._calculate_trend(values, metric_name)
            trends[metric_name] = trend.value
        
        return trends
    
    def _calculate_trend(self, values: List[float], metric_name: str) -> TrendDirection:
        """Calcula la tendencia de una serie de valores"""
        if len(values) < 3:
            return TrendDirection.STABLE
        
        # Regresión lineal simple
        n = len(values)
        x = list(range(n))
        mean_x = statistics.mean(x)
        mean_y = statistics.mean(values)
        
        numerator = sum((x[i] - mean_x) * (values[i] - mean_y) for i in range(n))
        denominator = sum((x[i] - mean_x) ** 2 for i in range(n))
        
        if denominator == 0:
            return TrendDirection.STABLE
        
        slope = numerator / denominator
        
        # Determinar dirección
        if metric_name in ['bandwidth_mbps', 'throughput_mbps', 'buffer_health_s']:
            # Más es mejor
            if slope > 0.1:
                return TrendDirection.IMPROVING
            elif slope < -0.1:
                if values[-1] < 2.0:  # Umbral crítico
                    return TrendDirection.CRITICAL
                return TrendDirection.DEGRADING
        else:
            # Menos es mejor
            if slope < -0.1:
                return TrendDirection.IMPROVING
            elif slope > 0.1:
                if values[-1] > 200:  # Umbral crítico
                    return TrendDirection.CRITICAL
                return TrendDirection.DEGRADING
        
        return TrendDirection.STABLE
    
    def _match_pattern(self, 
                      metrics: StreamMetrics,
                      trends: Dict[str, str],
                      signature: Dict[str, any]) -> float:
        """
        Calcula qué tan bien coinciden las métricas actuales con un patrón de anomalía.
        Returns: Score de 0-1
        """
        matches = 0
        total_checks = 0
        
        for key, expected in signature.items():
            total_checks += 1
            
            if key.endswith('_trend'):
                metric_name = key.replace('_trend', '')
                if metric_name in trends:
                    if isinstance(expected, list):
                        if trends[metric_name] in [e.value for e in expected]:
                            matches += 1
                    else:
                        if trends[metric_name] == expected.value:
                            matches += 1
            
            elif key == 'jitter_high':
                if metrics.jitter_ms > 50:
                    matches += 1
            
            elif key == 'error_rate_high':
                if metrics.error_code >= 400:
                    matches += 1
            
            elif key == 'packet_loss_low':
                if metrics.packet_loss_pct < 1.0:
                    matches += 1
            
            elif key == 'bandwidth_capped':
                # Detectar si el bandwidth está limitado artificialmente
                if 1.0 < metrics.bandwidth_mbps < 5.0:
                    matches += 1
            
            elif key == 'throughput_constant_low':
                if metrics.throughput_mbps < 3.0:
                    matches += 1
            
            elif key == 'error_rate_low':
                if metrics.error_code < 400:
                    matches += 1
            
            elif key == 'rtt_unstable':
                if metrics.jitter_ms > 30:
                    matches += 1
            
            elif key == 'buffer_health_critical':
                if metrics.buffer_health_s < 5.0:
                    matches += 1
            
            elif key == 'throughput_below_bitrate':
                # Asumir bitrate mínimo de 3 Mbps para FHD
                if metrics.throughput_mbps < 3.0:
                    matches += 1
        
        return matches / total_checks if total_checks > 0 else 0.0
    
    def _estimate_time_to_freeze(self,
                                metrics: StreamMetrics,
                                trends: Dict[str, str],
                                profile_target: Dict[str, any]) -> int:
        """
        Estima cuánto tiempo falta hasta que ocurra un freeze (en ms).
        """
        # Si el buffer está crítico, el freeze es inminente
        if metrics.buffer_health_s < 3.0:
            return int(metrics.buffer_health_s * 1000)  # Tiempo restante del buffer
        
        # Si el throughput está por debajo del bitrate, calcular cuándo se agotará el buffer
        target_bitrate = profile_target.get('bitrate_mbps', 3.0)
        if metrics.throughput_mbps < target_bitrate:
            # Tasa de drenaje del buffer
            drain_rate_s_per_s = 1.0 - (metrics.throughput_mbps / target_bitrate)
            time_to_empty_s = metrics.buffer_health_s / drain_rate_s_per_s
            return int(time_to_empty_s * 1000)
        
        # Si las tendencias son críticas, estimar basándose en la velocidad de degradación
        if trends.get('bandwidth_mbps') == TrendDirection.CRITICAL.value:
            return 1000  # 1 segundo
        elif trends.get('bandwidth_mbps') == TrendDirection.DEGRADING.value:
            return 3000  # 3 segundos
        
        # Por defecto, asumir que hay tiempo suficiente
        return 5000  # 5 segundos
    
    def _calculate_severity(self, confidence: float, time_to_freeze_ms: int) -> str:
        """Calcula la severidad de la predicción"""
        if confidence > 0.9 and time_to_freeze_ms < 1000:
            return 'critical'
        elif confidence > 0.85 and time_to_freeze_ms < 3000:
            return 'high'
        elif confidence > 0.75 and time_to_freeze_ms < 5000:
            return 'medium'
        else:
            return 'low'
    
    def _adjust_action(self,
                      base_action: RecommendedAction,
                      severity: str,
                      player_capabilities: Dict[str, any],
                      metrics: StreamMetrics) -> RecommendedAction:
        """
        Ajusta la acción recomendada basándose en severidad y capacidades del player.
        """
        # Si la severidad es crítica, siempre hacer fallback de emergencia
        if severity == 'critical':
            return RecommendedAction.EMERGENCY_FALLBACK
        
        # Si el player no soporta parallel downloads, no recomendar esa acción
        if base_action == RecommendedAction.ENABLE_PARALLEL_DOWNLOADS:
            max_parallel = player_capabilities.get('max_parallel_downloads', 2)
            if max_parallel < 3:
                return RecommendedAction.DOWNGRADE_PROFILE_MODERATE
        
        # Si el buffer está muy bajo, priorizar aumentar buffer
        if metrics.buffer_health_s < 5.0:
            if severity == 'high':
                return RecommendedAction.INCREASE_BUFFER_AGGRESSIVE
            else:
                return RecommendedAction.INCREASE_BUFFER_MODERATE
        
        return base_action
    
    def get_accuracy_stats(self) -> Dict[str, float]:
        """Retorna estadísticas de precisión del motor de inferencia"""
        total_predictions = self.true_positives + self.false_positives
        if total_predictions == 0:
            return {'accuracy': 0.0, 'precision': 0.0, 'total_predictions': 0}
        
        accuracy = self.true_positives / total_predictions
        return {
            'accuracy': accuracy,
            'precision': accuracy,  # En este contexto son equivalentes
            'total_predictions': total_predictions,
            'true_positives': self.true_positives,
            'false_positives': self.false_positives
        }
    
    def report_outcome(self, prediction: FreezePrediction, actual_freeze_occurred: bool):
        """
        Reporta el resultado real para mejorar la precisión del modelo.
        """
        if prediction.will_freeze and actual_freeze_occurred:
            self.true_positives += 1
        elif prediction.will_freeze and not actual_freeze_occurred:
            self.false_positives += 1
