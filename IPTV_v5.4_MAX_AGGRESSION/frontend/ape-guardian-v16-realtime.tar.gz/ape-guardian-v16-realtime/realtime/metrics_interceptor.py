"""
APE Guardian Engine v16 - Metrics Interceptor
Intercepta y analiza métricas del stream en tiempo real (cada 50-100ms).
"""

import time
import statistics
from collections import deque
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict
from enum import Enum


class TrendDirection(Enum):
    """Dirección de la tendencia de una métrica"""
    IMPROVING = "improving"
    STABLE = "stable"
    DEGRADING = "degrading"
    CRITICAL = "critical"


@dataclass
class StreamMetrics:
    """Métricas capturadas en un momento específico"""
    timestamp_ms: float
    bandwidth_mbps: float
    rtt_ms: float
    packet_loss_pct: float
    jitter_ms: float
    throughput_mbps: float
    buffer_health_s: float
    error_code: int
    bytes_downloaded: int
    segments_downloaded: int
    
    def to_dict(self) -> dict:
        return asdict(self)


class MetricsInterceptor:
    """
    Intercepta y analiza métricas del stream en tiempo real.
    Frecuencia: 50-100ms (configurable por player)
    Tiempo de ejecución por captura: <10ms
    """
    
    def __init__(self, session_id: str, telemetry_interval_ms: int = 100):
        self.session_id = session_id
        self.interval_ms = telemetry_interval_ms
        
        # Buffer de métricas (últimos 10 segundos)
        self.metrics_buffer = deque(maxlen=int(10000 / telemetry_interval_ms))
        
        # Contadores acumulativos
        self.total_bytes = 0
        self.total_segments = 0
        self.total_errors = 0
        self.start_time_ms = time.time() * 1000
        
        # Última métrica capturada
        self.last_metrics: Optional[StreamMetrics] = None
        
        # Umbrales de alerta
        self.thresholds = {
            'bandwidth_mbps': {'warning': 5.0, 'critical': 2.0},
            'rtt_ms': {'warning': 100, 'critical': 300},
            'packet_loss_pct': {'warning': 1.0, 'critical': 5.0},
            'jitter_ms': {'warning': 20, 'critical': 50},
            'buffer_health_s': {'warning': 10, 'critical': 5}
        }
    
    def capture_metrics(self, 
                       request_headers: Dict[str, str],
                       response_headers: Dict[str, str],
                       response_time_ms: float,
                       content_length: int) -> StreamMetrics:
        """
        Captura métricas de la petición/respuesta actual.
        
        Args:
            request_headers: Headers de la petición
            response_headers: Headers de la respuesta
            response_time_ms: Tiempo de respuesta en ms
            content_length: Tamaño del contenido descargado
            
        Returns:
            StreamMetrics con las métricas capturadas
        """
        current_time_ms = time.time() * 1000
        
        # Actualizar contadores
        self.total_bytes += content_length
        self.total_segments += 1
        
        # Calcular métricas
        bandwidth_mbps = self._calculate_bandwidth(content_length, response_time_ms)
        rtt_ms = self._extract_rtt(response_headers, response_time_ms)
        packet_loss_pct = self._estimate_packet_loss()
        jitter_ms = self._calculate_jitter(rtt_ms)
        throughput_mbps = self._calculate_throughput()
        buffer_health_s = self._extract_buffer_health(request_headers)
        error_code = int(response_headers.get('status', response_headers.get('Status', 200)))
        
        # Crear objeto de métricas
        metrics = StreamMetrics(
            timestamp_ms=current_time_ms,
            bandwidth_mbps=bandwidth_mbps,
            rtt_ms=rtt_ms,
            packet_loss_pct=packet_loss_pct,
            jitter_ms=jitter_ms,
            throughput_mbps=throughput_mbps,
            buffer_health_s=buffer_health_s,
            error_code=error_code,
            bytes_downloaded=content_length,
            segments_downloaded=1
        )
        
        # Agregar al buffer
        self.metrics_buffer.append(metrics)
        self.last_metrics = metrics
        
        # Contar errores
        if error_code >= 400:
            self.total_errors += 1
        
        return metrics
    
    def _calculate_bandwidth(self, content_length: int, response_time_ms: float) -> float:
        """
        Calcula el ancho de banda instantáneo en Mbps.
        """
        if response_time_ms <= 0:
            return 0.0
        
        # Convertir bytes a megabits y ms a segundos
        megabits = (content_length * 8) / 1_000_000
        seconds = response_time_ms / 1000
        
        return megabits / seconds if seconds > 0 else 0.0
    
    def _extract_rtt(self, response_headers: Dict[str, str], response_time_ms: float) -> float:
        """
        Extrae o estima el RTT (Round Trip Time) en ms.
        """
        # Intentar extraer de headers personalizados
        if 'X-RTT-Ms' in response_headers:
            try:
                return float(response_headers['X-RTT-Ms'])
            except ValueError:
                pass
        
        # Usar response_time como aproximación del RTT
        return response_time_ms
    
    def _estimate_packet_loss(self) -> float:
        """
        Estima el porcentaje de pérdida de paquetes basándose en errores y timeouts.
        """
        if len(self.metrics_buffer) < 10:
            return 0.0
        
        # Contar errores en la ventana reciente
        recent_errors = sum(1 for m in list(self.metrics_buffer)[-10:] if m.error_code >= 400)
        
        # Estimar pérdida de paquetes
        return (recent_errors / 10) * 100
    
    def _calculate_jitter(self, current_rtt_ms: float) -> float:
        """
        Calcula el jitter (variación del RTT) en ms.
        """
        if len(self.metrics_buffer) < 2:
            return 0.0
        
        # Obtener RTTs recientes
        recent_rtts = [m.rtt_ms for m in list(self.metrics_buffer)[-10:]]
        recent_rtts.append(current_rtt_ms)
        
        # Calcular desviación estándar como medida de jitter
        if len(recent_rtts) >= 2:
            return statistics.stdev(recent_rtts)
        
        return 0.0
    
    def _calculate_throughput(self) -> float:
        """
        Calcula el throughput promedio en Mbps (últimos 5 segundos).
        """
        if not self.metrics_buffer:
            return 0.0
        
        current_time_ms = time.time() * 1000
        window_ms = 5000  # 5 segundos
        
        # Filtrar métricas de los últimos 5 segundos
        recent_metrics = [
            m for m in self.metrics_buffer 
            if current_time_ms - m.timestamp_ms <= window_ms
        ]
        
        if not recent_metrics:
            return 0.0
        
        # Calcular throughput promedio
        total_bytes = sum(m.bytes_downloaded for m in recent_metrics)
        time_span_s = (current_time_ms - recent_metrics[0].timestamp_ms) / 1000
        
        if time_span_s <= 0:
            return 0.0
        
        megabits = (total_bytes * 8) / 1_000_000
        return megabits / time_span_s
    
    def _extract_buffer_health(self, request_headers: Dict[str, str]) -> float:
        """
        Extrae el estado del buffer del player (en segundos).
        """
        # Intentar extraer de headers personalizados
        if 'X-Buffer-Level-Ms' in request_headers:
            try:
                return float(request_headers['X-Buffer-Level-Ms']) / 1000
            except ValueError:
                pass
        
        # Estimar basándose en el comportamiento del player
        if len(self.metrics_buffer) < 5:
            return 15.0  # Asumir buffer saludable al inicio
        
        # Si hay muchas peticiones rápidas, el buffer está bajo
        recent_intervals = []
        recent_metrics = list(self.metrics_buffer)[-5:]
        for i in range(1, len(recent_metrics)):
            interval_ms = recent_metrics[i].timestamp_ms - recent_metrics[i-1].timestamp_ms
            recent_intervals.append(interval_ms)
        
        if recent_intervals:
            avg_interval_ms = statistics.mean(recent_intervals)
            # Si las peticiones son muy frecuentes (<1s), el buffer está bajo
            if avg_interval_ms < 1000:
                return 5.0  # Buffer crítico
            elif avg_interval_ms < 3000:
                return 10.0  # Buffer bajo
            else:
                return 20.0  # Buffer saludable
        
        return 15.0
    
    def get_trend(self, metric_name: str, window_ms: int = 1000) -> TrendDirection:
        """
        Analiza la tendencia de una métrica en una ventana de tiempo.
        
        Args:
            metric_name: Nombre de la métrica (ej: 'bandwidth_mbps', 'rtt_ms')
            window_ms: Ventana de tiempo en ms (default: 1 segundo)
            
        Returns:
            TrendDirection indicando la tendencia
        """
        if len(self.metrics_buffer) < 3:
            return TrendDirection.STABLE
        
        current_time_ms = time.time() * 1000
        
        # Filtrar métricas en la ventana
        recent_metrics = [
            m for m in self.metrics_buffer
            if current_time_ms - m.timestamp_ms <= window_ms
        ]
        
        if len(recent_metrics) < 3:
            return TrendDirection.STABLE
        
        # Extraer valores de la métrica
        values = [getattr(m, metric_name) for m in recent_metrics]
        
        # Calcular tendencia usando regresión lineal simple
        n = len(values)
        x = list(range(n))
        mean_x = statistics.mean(x)
        mean_y = statistics.mean(values)
        
        numerator = sum((x[i] - mean_x) * (values[i] - mean_y) for i in range(n))
        denominator = sum((x[i] - mean_x) ** 2 for i in range(n))
        
        if denominator == 0:
            return TrendDirection.STABLE
        
        slope = numerator / denominator
        
        # Determinar dirección basándose en la pendiente
        # Para métricas donde "más es mejor" (bandwidth, throughput, buffer_health)
        if metric_name in ['bandwidth_mbps', 'throughput_mbps', 'buffer_health_s']:
            if slope > 0.1:
                return TrendDirection.IMPROVING
            elif slope < -0.1:
                # Verificar si está en zona crítica
                current_value = values[-1]
                threshold = self.thresholds.get(metric_name, {}).get('critical', 0)
                if current_value < threshold:
                    return TrendDirection.CRITICAL
                return TrendDirection.DEGRADING
            else:
                return TrendDirection.STABLE
        
        # Para métricas donde "menos es mejor" (rtt, packet_loss, jitter)
        else:
            if slope < -0.1:
                return TrendDirection.IMPROVING
            elif slope > 0.1:
                # Verificar si está en zona crítica
                current_value = values[-1]
                threshold = self.thresholds.get(metric_name, {}).get('critical', float('inf'))
                if current_value > threshold:
                    return TrendDirection.CRITICAL
                return TrendDirection.DEGRADING
            else:
                return TrendDirection.STABLE
    
    def get_summary(self) -> Dict[str, any]:
        """
        Genera un resumen de las métricas actuales.
        """
        if not self.last_metrics:
            return {}
        
        return {
            'session_id': self.session_id,
            'current_metrics': self.last_metrics.to_dict(),
            'trends': {
                'bandwidth': self.get_trend('bandwidth_mbps').value,
                'rtt': self.get_trend('rtt_ms').value,
                'packet_loss': self.get_trend('packet_loss_pct').value,
                'jitter': self.get_trend('jitter_ms').value,
                'throughput': self.get_trend('throughput_mbps').value,
                'buffer_health': self.get_trend('buffer_health_s').value
            },
            'totals': {
                'bytes_downloaded': self.total_bytes,
                'segments_downloaded': self.total_segments,
                'errors': self.total_errors,
                'uptime_s': (time.time() * 1000 - self.start_time_ms) / 1000
            }
        }
    
    def is_healthy(self) -> Tuple[bool, List[str]]:
        """
        Verifica si el stream está saludable.
        
        Returns:
            (is_healthy, list_of_warnings)
        """
        if not self.last_metrics:
            return True, []
        
        warnings = []
        
        # Verificar cada métrica contra umbrales
        if self.last_metrics.bandwidth_mbps < self.thresholds['bandwidth_mbps']['critical']:
            warnings.append(f"Bandwidth crítico: {self.last_metrics.bandwidth_mbps:.2f} Mbps")
        
        if self.last_metrics.rtt_ms > self.thresholds['rtt_ms']['critical']:
            warnings.append(f"Latencia crítica: {self.last_metrics.rtt_ms:.0f} ms")
        
        if self.last_metrics.packet_loss_pct > self.thresholds['packet_loss_pct']['critical']:
            warnings.append(f"Pérdida de paquetes crítica: {self.last_metrics.packet_loss_pct:.1f}%")
        
        if self.last_metrics.jitter_ms > self.thresholds['jitter_ms']['critical']:
            warnings.append(f"Jitter crítico: {self.last_metrics.jitter_ms:.1f} ms")
        
        if self.last_metrics.buffer_health_s < self.thresholds['buffer_health_s']['critical']:
            warnings.append(f"Buffer crítico: {self.last_metrics.buffer_health_s:.1f} s")
        
        return len(warnings) == 0, warnings
