"""
APE Guardian Engine v16 - Player Detector
Detecta el tipo de player basándose en User-Agent, headers y fingerprinting.
"""

import re
from typing import Dict, Optional
from dataclasses import dataclass


@dataclass
class PlayerCapabilities:
    """Capacidades del player detectado"""
    hevc_support: bool
    hdr_support: bool
    dolby_atmos_support: bool
    max_parallel_downloads: int
    max_resolution: str
    preferred_codecs: list[str]
    buffer_strategy: str
    telemetry_interval_ms: int


class PlayerDetector:
    """
    Detecta el tipo de player y sus capacidades para adaptar la estrategia de telemetría.
    Tiempo de ejecución: <2ms
    """
    
    # Base de datos de players conocidos
    PLAYERS_DB = {
        'vlc': {
            'patterns': [r'VLC', r'libvlc', r'VideoLAN'],
            'capabilities': PlayerCapabilities(
                hevc_support=True,
                hdr_support=False,
                dolby_atmos_support=False,
                max_parallel_downloads=2,
                max_resolution='4K',
                preferred_codecs=['h264', 'hevc'],
                buffer_strategy='moderate',
                telemetry_interval_ms=100
            )
        },
        'exoplayer': {
            'patterns': [r'ExoPlayer', r'Android.*Chrome'],
            'capabilities': PlayerCapabilities(
                hevc_support=True,
                hdr_support=True,
                dolby_atmos_support=True,
                max_parallel_downloads=4,
                max_resolution='8K',
                preferred_codecs=['hevc', 'av1', 'vp9', 'h264'],
                buffer_strategy='aggressive',
                telemetry_interval_ms=50
            )
        },
        'hls_js': {
            'patterns': [r'Mozilla.*Chrome', r'Mozilla.*Safari', r'Mozilla.*Edge'],
            'capabilities': PlayerCapabilities(
                hevc_support=False,  # Depende del navegador
                hdr_support=False,
                dolby_atmos_support=False,
                max_parallel_downloads=6,
                max_resolution='4K',
                preferred_codecs=['h264', 'vp9'],
                buffer_strategy='adaptive',
                telemetry_interval_ms=100
            )
        },
        'ott_navigator': {
            'patterns': [r'OTT-Navigator', r'IPTV', r'X-OTT-Navigator'],
            'capabilities': PlayerCapabilities(
                hevc_support=True,
                hdr_support=True,
                dolby_atmos_support=True,
                max_parallel_downloads=4,
                max_resolution='4K',
                preferred_codecs=['hevc', 'h264'],
                buffer_strategy='ultra_aggressive',
                telemetry_interval_ms=50
            )
        },
        'kodi': {
            'patterns': [r'Kodi', r'XBMC'],
            'capabilities': PlayerCapabilities(
                hevc_support=True,
                hdr_support=True,
                dolby_atmos_support=True,
                max_parallel_downloads=3,
                max_resolution='4K',
                preferred_codecs=['hevc', 'h264'],
                buffer_strategy='aggressive',
                telemetry_interval_ms=100
            )
        },
        'mpv': {
            'patterns': [r'mpv', r'libmpv'],
            'capabilities': PlayerCapabilities(
                hevc_support=True,
                hdr_support=True,
                dolby_atmos_support=True,
                max_parallel_downloads=4,
                max_resolution='8K',
                preferred_codecs=['hevc', 'av1', 'vp9', 'h264'],
                buffer_strategy='aggressive',
                telemetry_interval_ms=50
            )
        },
        'ffmpeg': {
            'patterns': [r'ffmpeg', r'Lavf'],
            'capabilities': PlayerCapabilities(
                hevc_support=True,
                hdr_support=True,
                dolby_atmos_support=True,
                max_parallel_downloads=1,
                max_resolution='8K',
                preferred_codecs=['hevc', 'h264'],
                buffer_strategy='moderate',
                telemetry_interval_ms=200
            )
        }
    }
    
    # Player por defecto si no se puede detectar
    DEFAULT_PLAYER = PlayerCapabilities(
        hevc_support=False,
        hdr_support=False,
        dolby_atmos_support=False,
        max_parallel_downloads=2,
        max_resolution='1080p',
        preferred_codecs=['h264'],
        buffer_strategy='moderate',
        telemetry_interval_ms=100
    )
    
    def detect(self, headers: Dict[str, str]) -> Dict[str, any]:
        """
        Detecta el player basándose en los headers de la petición.
        
        Args:
            headers: Headers HTTP de la petición
            
        Returns:
            {
                'player_type': str,
                'player_version': str,
                'capabilities': PlayerCapabilities,
                'fingerprint': str,
                'confidence': float (0-1)
            }
        """
        user_agent = headers.get('User-Agent', headers.get('user-agent', ''))
        
        # Intentar detectar player por User-Agent
        for player_name, player_data in self.PLAYERS_DB.items():
            for pattern in player_data['patterns']:
                if re.search(pattern, user_agent, re.IGNORECASE):
                    return {
                        'player_type': player_name,
                        'player_version': self._extract_version(user_agent),
                        'capabilities': player_data['capabilities'],
                        'fingerprint': self._generate_fingerprint(headers),
                        'confidence': 0.9
                    }
        
        # Detectar por headers personalizados
        if 'X-OTT-Navigator-Version' in headers:
            return {
                'player_type': 'ott_navigator',
                'player_version': headers['X-OTT-Navigator-Version'],
                'capabilities': self.PLAYERS_DB['ott_navigator']['capabilities'],
                'fingerprint': self._generate_fingerprint(headers),
                'confidence': 1.0
            }
        
        if 'X-Player-Type' in headers:
            player_type = headers['X-Player-Type'].lower()
            if player_type in self.PLAYERS_DB:
                return {
                    'player_type': player_type,
                    'player_version': headers.get('X-Player-Version', 'unknown'),
                    'capabilities': self.PLAYERS_DB[player_type]['capabilities'],
                    'fingerprint': self._generate_fingerprint(headers),
                    'confidence': 1.0
                }
        
        # Player desconocido - usar configuración conservadora
        return {
            'player_type': 'unknown',
            'player_version': 'unknown',
            'capabilities': self.DEFAULT_PLAYER,
            'fingerprint': self._generate_fingerprint(headers),
            'confidence': 0.3
        }
    
    def _extract_version(self, user_agent: str) -> str:
        """Extrae la versión del player del User-Agent"""
        # Buscar patrones como "VLC/3.0.16", "Chrome/125.0.0.0", etc.
        version_patterns = [
            r'VLC/(\d+\.\d+\.\d+)',
            r'Chrome/(\d+\.\d+\.\d+\.\d+)',
            r'ExoPlayer/(\d+\.\d+\.\d+)',
            r'OTT-Navigator/(\d+\.\d+\.\d+)',
            r'Kodi/(\d+\.\d+)',
            r'mpv (\d+\.\d+\.\d+)'
        ]
        
        for pattern in version_patterns:
            match = re.search(pattern, user_agent)
            if match:
                return match.group(1)
        
        return 'unknown'
    
    def _generate_fingerprint(self, headers: Dict[str, str]) -> str:
        """
        Genera un fingerprint único del player basándose en los headers.
        Útil para detectar el mismo player en peticiones futuras.
        """
        import hashlib
        
        # Combinar headers relevantes para fingerprinting
        fingerprint_data = '|'.join([
            headers.get('User-Agent', ''),
            headers.get('Accept', ''),
            headers.get('Accept-Language', ''),
            headers.get('X-Player-Type', ''),
            headers.get('X-Device-Type', ''),
            headers.get('X-Screen-Resolution', '')
        ])
        
        return hashlib.md5(fingerprint_data.encode()).hexdigest()[:16]
    
    def adjust_capabilities_by_network(self, 
                                      capabilities: PlayerCapabilities,
                                      bandwidth_mbps: float,
                                      rtt_ms: float) -> PlayerCapabilities:
        """
        Ajusta las capacidades del player basándose en las condiciones de red.
        
        Args:
            capabilities: Capacidades originales del player
            bandwidth_mbps: Ancho de banda disponible
            rtt_ms: Latencia de red
            
        Returns:
            Capacidades ajustadas
        """
        adjusted = PlayerCapabilities(
            hevc_support=capabilities.hevc_support,
            hdr_support=capabilities.hdr_support and bandwidth_mbps > 15,
            dolby_atmos_support=capabilities.dolby_atmos_support and bandwidth_mbps > 10,
            max_parallel_downloads=capabilities.max_parallel_downloads,
            max_resolution=capabilities.max_resolution,
            preferred_codecs=capabilities.preferred_codecs,
            buffer_strategy=capabilities.buffer_strategy,
            telemetry_interval_ms=capabilities.telemetry_interval_ms
        )
        
        # Ajustar resolución máxima según ancho de banda
        if bandwidth_mbps < 3:
            adjusted.max_resolution = '480p'
        elif bandwidth_mbps < 5:
            adjusted.max_resolution = '720p'
        elif bandwidth_mbps < 10:
            adjusted.max_resolution = '1080p'
        elif bandwidth_mbps < 25:
            adjusted.max_resolution = '4K'
        else:
            adjusted.max_resolution = '8K'
        
        # Ajustar parallel downloads según latencia
        if rtt_ms > 200:
            adjusted.max_parallel_downloads = max(1, capabilities.max_parallel_downloads - 2)
        elif rtt_ms > 100:
            adjusted.max_parallel_downloads = max(2, capabilities.max_parallel_downloads - 1)
        
        # Ajustar estrategia de buffer según latencia
        if rtt_ms > 300:
            adjusted.buffer_strategy = 'ultra_aggressive'
        elif rtt_ms > 150:
            adjusted.buffer_strategy = 'aggressive'
        
        return adjusted
