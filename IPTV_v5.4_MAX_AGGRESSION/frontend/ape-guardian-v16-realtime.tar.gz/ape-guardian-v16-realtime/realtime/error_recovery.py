"""
APE Guardian Engine v16 - Error Recovery Engine
Gestión exhaustiva de errores HTTP 400-505 con fallback/failover automático.
"""

import time
import asyncio
from typing import Dict, Optional, Tuple
from dataclasses import dataclass
from enum import Enum


class RecoveryAction(Enum):
    """Tipo de acción de recuperación"""
    REGENERATE_REQUEST = "regenerate_request"
    REFRESH_JWT = "refresh_jwt"
    ROTATE_HEADERS = "rotate_headers"
    FAILOVER_TO_BACKUP = "failover_to_backup"
    REDUCE_TIMEOUT = "reduce_timeout"
    EXPONENTIAL_BACKOFF = "exponential_backoff"
    FAILOVER_IMMEDIATE = "failover_immediate"
    SWITCH_CDN = "switch_cdn"
    WAIT_AND_RETRY = "wait_and_retry"
    REDUCE_QUALITY = "reduce_quality"
    ABORT_AND_LOG = "abort_and_log"


@dataclass
class ErrorStrategy:
    """Estrategia de recuperación para un código de error"""
    action: RecoveryAction
    retry: bool
    delay_ms: int
    max_attempts: int
    fallback_action: Optional[RecoveryAction] = None


@dataclass
class RecoveryAttempt:
    """Registro de un intento de recuperación"""
    timestamp_ms: float
    error_code: int
    action: RecoveryAction
    success: bool
    attempts: int
    total_time_ms: float


class ErrorRecoveryEngine:
    """
    Gestiona la recuperación automática ante errores HTTP 400-505.
    Objetivo: Que estos errores nunca lleguen al usuario.
    """
    
    # Estrategias exhaustivas para todos los códigos de error 400-505
    ERROR_STRATEGIES = {
        # 4xx - Errores del cliente
        400: ErrorStrategy(RecoveryAction.REGENERATE_REQUEST, True, 0, 3, RecoveryAction.ABORT_AND_LOG),
        401: ErrorStrategy(RecoveryAction.REFRESH_JWT, True, 0, 3, RecoveryAction.FAILOVER_TO_BACKUP),
        402: ErrorStrategy(RecoveryAction.ABORT_AND_LOG, False, 0, 1),  # Payment Required
        403: ErrorStrategy(RecoveryAction.ROTATE_HEADERS, True, 100, 5, RecoveryAction.SWITCH_CDN),
        404: ErrorStrategy(RecoveryAction.FAILOVER_TO_BACKUP, False, 0, 1),
        405: ErrorStrategy(RecoveryAction.REGENERATE_REQUEST, True, 0, 2),  # Method Not Allowed
        406: ErrorStrategy(RecoveryAction.REGENERATE_REQUEST, True, 0, 2),  # Not Acceptable
        407: ErrorStrategy(RecoveryAction.ABORT_AND_LOG, False, 0, 1),  # Proxy Auth Required
        408: ErrorStrategy(RecoveryAction.REDUCE_TIMEOUT, True, 50, 5, RecoveryAction.REDUCE_QUALITY),
        409: ErrorStrategy(RecoveryAction.WAIT_AND_RETRY, True, 500, 3),  # Conflict
        410: ErrorStrategy(RecoveryAction.FAILOVER_TO_BACKUP, False, 0, 1),  # Gone
        411: ErrorStrategy(RecoveryAction.REGENERATE_REQUEST, True, 0, 2),  # Length Required
        412: ErrorStrategy(RecoveryAction.REGENERATE_REQUEST, True, 0, 2),  # Precondition Failed
        413: ErrorStrategy(RecoveryAction.REDUCE_QUALITY, True, 0, 3),  # Payload Too Large
        414: ErrorStrategy(RecoveryAction.REGENERATE_REQUEST, True, 0, 2),  # URI Too Long
        415: ErrorStrategy(RecoveryAction.REGENERATE_REQUEST, True, 0, 2),  # Unsupported Media Type
        416: ErrorStrategy(RecoveryAction.REGENERATE_REQUEST, True, 0, 2),  # Range Not Satisfiable
        417: ErrorStrategy(RecoveryAction.REGENERATE_REQUEST, True, 0, 2),  # Expectation Failed
        418: ErrorStrategy(RecoveryAction.WAIT_AND_RETRY, True, 1000, 2),  # I'm a teapot
        421: ErrorStrategy(RecoveryAction.SWITCH_CDN, True, 100, 3),  # Misdirected Request
        422: ErrorStrategy(RecoveryAction.REGENERATE_REQUEST, True, 0, 2),  # Unprocessable Entity
        423: ErrorStrategy(RecoveryAction.WAIT_AND_RETRY, True, 500, 3),  # Locked
        424: ErrorStrategy(RecoveryAction.REGENERATE_REQUEST, True, 0, 2),  # Failed Dependency
        425: ErrorStrategy(RecoveryAction.WAIT_AND_RETRY, True, 100, 3),  # Too Early
        426: ErrorStrategy(RecoveryAction.REGENERATE_REQUEST, True, 0, 2),  # Upgrade Required
        428: ErrorStrategy(RecoveryAction.REGENERATE_REQUEST, True, 0, 2),  # Precondition Required
        429: ErrorStrategy(RecoveryAction.EXPONENTIAL_BACKOFF, True, 1000, 5, RecoveryAction.REDUCE_QUALITY),
        431: ErrorStrategy(RecoveryAction.REGENERATE_REQUEST, True, 0, 2),  # Request Header Fields Too Large
        451: ErrorStrategy(RecoveryAction.ROTATE_HEADERS, True, 100, 3, RecoveryAction.SWITCH_CDN),  # Unavailable For Legal Reasons
        
        # 5xx - Errores del servidor
        500: ErrorStrategy(RecoveryAction.FAILOVER_IMMEDIATE, True, 0, 3, RecoveryAction.REDUCE_QUALITY),
        501: ErrorStrategy(RecoveryAction.REGENERATE_REQUEST, True, 0, 2),  # Not Implemented
        502: ErrorStrategy(RecoveryAction.SWITCH_CDN, True, 100, 5, RecoveryAction.FAILOVER_TO_BACKUP),
        503: ErrorStrategy(RecoveryAction.WAIT_AND_RETRY, True, 500, 10, RecoveryAction.FAILOVER_TO_BACKUP),
        504: ErrorStrategy(RecoveryAction.REDUCE_QUALITY, True, 0, 3, RecoveryAction.SWITCH_CDN),
        505: ErrorStrategy(RecoveryAction.REGENERATE_REQUEST, True, 0, 2),  # HTTP Version Not Supported
        506: ErrorStrategy(RecoveryAction.REGENERATE_REQUEST, True, 0, 2),  # Variant Also Negotiates
        507: ErrorStrategy(RecoveryAction.REDUCE_QUALITY, True, 0, 3),  # Insufficient Storage
        508: ErrorStrategy(RecoveryAction.ABORT_AND_LOG, False, 0, 1),  # Loop Detected
        510: ErrorStrategy(RecoveryAction.REGENERATE_REQUEST, True, 0, 2),  # Not Extended
        511: ErrorStrategy(RecoveryAction.REFRESH_JWT, True, 0, 3),  # Network Authentication Required
    }
    
    def __init__(self):
        self.recovery_history = []
        self.error_counts = {}
        self.backoff_multipliers = {}  # Para exponential backoff
        
    async def recover(self, 
                     error_code: int,
                     context: Dict[str, any],
                     attempt_number: int = 1) -> Tuple[bool, Optional[Dict[str, any]]]:
        """
        Ejecuta la estrategia de recuperación para el error dado.
        
        Args:
            error_code: Código de error HTTP
            context: Contexto de la petición (headers, JWT, etc.)
            attempt_number: Número de intento actual
            
        Returns:
            (success, recovery_data)
        """
        start_time_ms = time.time() * 1000
        
        # Obtener estrategia para este error
        strategy = self.ERROR_STRATEGIES.get(
            error_code,
            ErrorStrategy(RecoveryAction.WAIT_AND_RETRY, True, 500, 3)  # Default strategy
        )
        
        # Verificar si hemos excedido el número máximo de intentos
        if attempt_number > strategy.max_attempts:
            # Intentar acción de fallback si existe
            if strategy.fallback_action:
                return await self._execute_action(
                    strategy.fallback_action,
                    context,
                    0  # Sin delay para fallback
                )
            return False, None
        
        # Incrementar contador de errores
        self.error_counts[error_code] = self.error_counts.get(error_code, 0) + 1
        
        # Aplicar delay si es necesario
        delay_ms = strategy.delay_ms
        
        # Para exponential backoff, aumentar el delay exponencialmente
        if strategy.action == RecoveryAction.EXPONENTIAL_BACKOFF:
            multiplier = self.backoff_multipliers.get(error_code, 1)
            delay_ms = strategy.delay_ms * multiplier
            self.backoff_multipliers[error_code] = multiplier * 2
        
        if delay_ms > 0:
            await asyncio.sleep(delay_ms / 1000)
        
        # Ejecutar acción de recuperación
        success, recovery_data = await self._execute_action(strategy.action, context, delay_ms)
        
        # Registrar intento
        elapsed_ms = time.time() * 1000 - start_time_ms
        attempt = RecoveryAttempt(
            timestamp_ms=time.time() * 1000,
            error_code=error_code,
            action=strategy.action,
            success=success,
            attempts=attempt_number,
            total_time_ms=elapsed_ms
        )
        self.recovery_history.append(attempt)
        
        # Si tuvo éxito, resetear el multiplicador de backoff
        if success and strategy.action == RecoveryAction.EXPONENTIAL_BACKOFF:
            self.backoff_multipliers[error_code] = 1
        
        # Verificar que no excedimos el tiempo objetivo de 30ms
        if elapsed_ms > 30 and delay_ms == 0:
            print(f"WARNING: Error recovery took {elapsed_ms:.1f}ms (target: <30ms)")
        
        return success, recovery_data
    
    async def _execute_action(self,
                             action: RecoveryAction,
                             context: Dict[str, any],
                             delay_ms: int) -> Tuple[bool, Optional[Dict[str, any]]]:
        """
        Ejecuta una acción de recuperación específica.
        """
        if action == RecoveryAction.REGENERATE_REQUEST:
            # Regenerar la petición con headers limpios
            return True, {
                'action': 'regenerate',
                'new_headers': self._clean_headers(context.get('headers', {}))
            }
        
        elif action == RecoveryAction.REFRESH_JWT:
            # Solicitar regeneración del JWT
            return True, {
                'action': 'refresh_jwt',
                'reason': 'authentication_error'
            }
        
        elif action == RecoveryAction.ROTATE_HEADERS:
            # Rotar headers para evadir detección
            return True, {
                'action': 'rotate_headers',
                'new_headers': self._rotate_headers(context.get('headers', {}))
            }
        
        elif action == RecoveryAction.FAILOVER_TO_BACKUP:
            # Cambiar a servidor/CDN de backup
            return True, {
                'action': 'failover',
                'target': 'backup_cdn',
                'priority': 'high'
            }
        
        elif action == RecoveryAction.REDUCE_TIMEOUT:
            # Reducir timeout para respuestas más rápidas
            current_timeout = context.get('timeout_ms', 30000)
            new_timeout = max(5000, current_timeout - 5000)
            return True, {
                'action': 'reduce_timeout',
                'new_timeout_ms': new_timeout
            }
        
        elif action == RecoveryAction.EXPONENTIAL_BACKOFF:
            # El delay ya se aplicó antes, solo indicar que se debe reintentar
            return True, {
                'action': 'retry',
                'backoff_applied': True,
                'delay_ms': delay_ms
            }
        
        elif action == RecoveryAction.FAILOVER_IMMEDIATE:
            # Failover inmediato sin delay
            return True, {
                'action': 'failover_immediate',
                'target': 'backup_cdn',
                'priority': 'critical'
            }
        
        elif action == RecoveryAction.SWITCH_CDN:
            # Cambiar a un CDN diferente
            return True, {
                'action': 'switch_cdn',
                'target': 'alternative_cdn',
                'reason': 'cdn_overload'
            }
        
        elif action == RecoveryAction.WAIT_AND_RETRY:
            # Esperar y reintentar
            return True, {
                'action': 'retry',
                'delay_ms': delay_ms
            }
        
        elif action == RecoveryAction.REDUCE_QUALITY:
            # Reducir calidad para aliviar la carga
            return True, {
                'action': 'reduce_quality',
                'downgrade_steps': 1,
                'reason': 'error_recovery'
            }
        
        elif action == RecoveryAction.ABORT_AND_LOG:
            # Abortar y registrar el error
            return False, {
                'action': 'abort',
                'reason': 'unrecoverable_error'
            }
        
        return False, None
    
    def _clean_headers(self, headers: Dict[str, str]) -> Dict[str, str]:
        """
        Limpia headers problemáticos que pueden causar errores.
        """
        cleaned = headers.copy()
        
        # Remover headers que pueden causar problemas
        problematic_headers = [
            'X-Forwarded-For',
            'X-Real-IP',
            'If-None-Match',
            'If-Modified-Since'
        ]
        
        for header in problematic_headers:
            cleaned.pop(header, None)
        
        return cleaned
    
    def _rotate_headers(self, headers: Dict[str, str]) -> Dict[str, str]:
        """
        Rota headers para evadir detección/bloqueo.
        """
        rotated = headers.copy()
        
        # Rotar User-Agent
        user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:126.0) Gecko/20100101 Firefox/126.0'
        ]
        
        import random
        rotated['User-Agent'] = random.choice(user_agents)
        
        # Rotar Accept-Language
        languages = ['en-US,en;q=0.9', 'es-ES,es;q=0.9', 'fr-FR,fr;q=0.9', 'de-DE,de;q=0.9']
        rotated['Accept-Language'] = random.choice(languages)
        
        return rotated
    
    def get_error_statistics(self) -> Dict[str, any]:
        """
        Retorna estadísticas de errores y recuperaciones.
        """
        if not self.recovery_history:
            return {'total_errors': 0}
        
        total_attempts = len(self.recovery_history)
        successful_recoveries = sum(1 for a in self.recovery_history if a.success)
        
        # Agrupar por código de error
        by_error_code = {}
        for attempt in self.recovery_history:
            code = attempt.error_code
            if code not in by_error_code:
                by_error_code[code] = {'total': 0, 'successful': 0, 'avg_time_ms': 0}
            by_error_code[code]['total'] += 1
            if attempt.success:
                by_error_code[code]['successful'] += 1
        
        # Calcular tiempo promedio de recuperación
        avg_recovery_time_ms = sum(a.total_time_ms for a in self.recovery_history) / total_attempts
        
        return {
            'total_errors': sum(self.error_counts.values()),
            'total_recovery_attempts': total_attempts,
            'successful_recoveries': successful_recoveries,
            'success_rate': successful_recoveries / total_attempts if total_attempts > 0 else 0,
            'avg_recovery_time_ms': avg_recovery_time_ms,
            'by_error_code': by_error_code,
            'most_common_errors': sorted(
                self.error_counts.items(),
                key=lambda x: x[1],
                reverse=True
            )[:5]
        }
    
    def should_abort(self, error_code: int) -> bool:
        """
        Determina si un error es irrecuperable y se debe abortar.
        """
        # Errores que indican problemas irrecuperables
        unrecoverable_errors = [402, 407, 410, 508]
        return error_code in unrecoverable_errors
